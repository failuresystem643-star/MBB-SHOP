# Al-Noor Shop Management System

> **PC nahi hai?** Poora system sirf Android phone (Termux app) pe, offline,
> bina PC ke chalane ke liye `MOBILE_SETUP_URDU.md` dekhein.

Local, LAN-based management system for a construction materials shop:
Sales, Purchases, Stock, Item Lookup, Customer Ledger, Supplier Ledger,
Cash Book, Payments/Receipts, Returns, Expenses, Reports, Dashboard,
Admin/Users, and Backup & Restore — all sharing one SQLite database.

## Project structure

```
backend/
  .env.example
  package.json
  src/
    server.js            # Express entry point
    db/
      init.js             # opens/creates data/shop.db, runs schema.sql
      schema.sql           # full table definitions
      seed.js               # creates default admin user + default settings
    middleware/
      auth.js               # JWT auth + role guard
    utils/
      generateCode.js        # sequential document numbers (INV-, PUR-, ...)
      ledger.js               # stock movement + customer/supplier/cash ledger helpers
    routes/
      auth.js, users.js, masters.js, items.js, customers.js, suppliers.js,
      purchases.js, sales.js, returns.js, payments.js, expenses.js,
      cashbook.js, stock.js, dashboard.js, reports.js, settings.js, backup.js
  data/                    # created automatically — holds shop.db (SQLite)

frontend/
  index.html
  vite.config.js
  package.json
  src/
    main.jsx, App.jsx, api.js, styles.css
    context/AuthContext.jsx
    components/  (Layout, Sidebar, Modal, Loading, Toast, ConfirmDialog, ItemLookup)
    pages/       (Login, Dashboard, Items, Masters, Stock, Sales, Purchases,
                  Returns, Payments, Expenses, Customers, CustomerLedger,
                  Suppliers, SupplierLedger, CashBook, Reports, Settings,
                  Backup, InvoicePrint)
```

## Setup

### 1. Backend

```
cd backend
npm install
cp .env.example .env      # optional — defaults work out of the box
npm run dev
```

This starts the API on `http://localhost:4000`, auto-creates `backend/data/shop.db`
from `schema.sql`, and seeds a default admin account:

```
username: admin
password: admin123
```

The console also prints your machine's LAN IP so you can reach the app from
an Android device / other PC on the same Wi-Fi.

### 2. Frontend

```
cd frontend
npm install
npm run dev
```

Opens on `http://localhost:5173` and proxies all `/api` calls to the backend
on port 4000 (see `vite.config.js`). On another device on the same network,
open `http://<your-pc-lan-ip>:5173`.

### 3. First login

Go to the frontend URL, log in with `admin` / `admin123`, then immediately
change the password from **Settings → Change Password**, and create
individual staff accounts under **Settings → Users**.

## How the modules connect

Every module reads/writes the same SQLite database (`backend/data/shop.db`):

- **Sales / Purchases / Returns** each move stock (`stock_movements`) and post
  to the relevant party ledger (`customer_ledger` / `supplier_ledger`) and,
  if paid in cash, to the **Cash Book** (`cash_transactions`).
- **Payments / Receipts** post directly to the customer or supplier ledger
  and, for cash, to the Cash Book.
- **Expenses** post to the Cash Book when paid in cash.
- **Item Lookup** and **Stock** both read live quantities computed from
  `stock_movements`.
- **Customer Ledger / Supplier Ledger** pages show the running balance per
  party, fed by sales, purchases, returns, and payments.
- **Dashboard** and **Reports** aggregate data across all of the above.
- **Backup & Restore** copies/restores the single `shop.db` file, so a
  restore rolls back every module at once (a safety snapshot is taken
  automatically before any restore).

Because everything reads and writes through the same `db/init.js`
connection, there is no risk of modules drifting out of sync.

## Notes

- Database file: `backend/data/shop.db` (SQLite, created automatically).
- Roles: `admin` (full access), `manager`, `sales` — enforced both by the
  UI and by the backend (`requireRole` middleware), so permissions can't
  be bypassed from the browser.
- To reset demo/sample data during development, see `DELETE /api/items/demo/reset`.
