const express = require('express');
const { db } = require('../db/init');
const { authRequired, requireRole } = require('../middleware/auth');
const { nextCode } = require('../utils/generateCode');
const { moveStock, addSupplierLedgerEntry, addCustomerLedgerEntry, addCashTransaction } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

// ================= PURCHASE RETURNS =================
router.get('/purchase-returns', (req, res) => {
  const { from, to } = req.query;
  let sql = `SELECT pr.*, s.name as supplier_name FROM purchase_returns pr JOIN suppliers s ON s.id = pr.supplier_id WHERE 1=1`;
  const params = [];
  if (from) { sql += ' AND pr.date >= ?'; params.push(from); }
  if (to) { sql += ' AND pr.date <= ?'; params.push(to); }
  sql += ' ORDER BY pr.id DESC';
  res.json(db.prepare(sql).all(...params));
});

router.get('/purchase-returns/:id', (req, res) => {
  const pr = db.prepare(`SELECT pr.*, s.name as supplier_name FROM purchase_returns pr JOIN suppliers s ON s.id = pr.supplier_id WHERE pr.id = ?`).get(req.params.id);
  if (!pr) return res.status(404).json({ error: 'Not found' });
  const items = db.prepare(`SELECT pri.*, i.item_code, i.item_name FROM purchase_return_items pri JOIN items i ON i.id = pri.item_id WHERE pri.purchase_return_id = ?`).all(req.params.id);
  res.json({ ...pr, items });
});

router.post('/purchase-returns', requireRole('manager'), (req, res) => {
  const b = req.body;
  if (!b.supplier_id) return res.status(400).json({ error: 'Supplier is required' });
  if (!Array.isArray(b.items) || b.items.length === 0) return res.status(400).json({ error: 'At least one item is required' });
  const date = b.date || new Date().toISOString().slice(0, 10);

  const txn = db.transaction(() => {
    const returnNo = nextCode(db, 'purchase_returns', 'return_no', 'PRET');
    let total = 0;
    const lines = b.items.map(it => {
      const qty = Number(it.quantity), rate = Number(it.rate);
      if (qty <= 0) throw new Error('Quantity must be greater than zero');
      const lineTotal = qty * rate;
      total += lineTotal;
      return { ...it, qty, rate, lineTotal };
    });
    const refund = Number(b.refund_amount) || 0;

    const info = db.prepare(`INSERT INTO purchase_returns (return_no, date, purchase_id, supplier_id, total, refund_amount, payment_method, notes)
      VALUES (?,?,?,?,?,?,?,?)`).run(returnNo, date, b.purchase_id || null, b.supplier_id, total, refund, b.payment_method || 'cash', b.notes || '');
    const returnId = info.lastInsertRowid;

    const insItem = db.prepare(`INSERT INTO purchase_return_items (purchase_return_id, item_id, quantity, rate, total) VALUES (?,?,?,?,?)`);
    for (const it of lines) {
      insItem.run(returnId, it.item_id, it.qty, it.rate, it.lineTotal);
      // reduce stock (goods leave shop back to supplier)
      moveStock(db, { itemId: it.item_id, date, type: 'purchase_return', reference: returnNo, qtyOut: it.qty });
    }

    // supplier balance decreases (debit)
    addSupplierLedgerEntry(db, { supplierId: b.supplier_id, date, reference: returnNo, description: `Purchase Return ${returnNo}`, debit: total });
    if (refund > 0 && (b.payment_method || 'cash') === 'cash') {
      addCashTransaction(db, { date, type: 'purchase_return', description: `Refund for Purchase Return ${returnNo}`, reference: returnNo, cashIn: refund });
    }

    return { id: returnId, return_no: returnNo, total };
  });

  try { res.json(txn()); } catch (e) { res.status(400).json({ error: e.message }); }
});

// ================= SALES RETURNS =================
router.get('/sales-returns', (req, res) => {
  const { from, to } = req.query;
  let sql = `SELECT sr.*, c.name as customer_name FROM sales_returns sr JOIN customers c ON c.id = sr.customer_id WHERE 1=1`;
  const params = [];
  if (from) { sql += ' AND sr.date >= ?'; params.push(from); }
  if (to) { sql += ' AND sr.date <= ?'; params.push(to); }
  sql += ' ORDER BY sr.id DESC';
  res.json(db.prepare(sql).all(...params));
});

router.get('/sales-returns/:id', (req, res) => {
  const sr = db.prepare(`SELECT sr.*, c.name as customer_name FROM sales_returns sr JOIN customers c ON c.id = sr.customer_id WHERE sr.id = ?`).get(req.params.id);
  if (!sr) return res.status(404).json({ error: 'Not found' });
  const items = db.prepare(`SELECT sri.*, i.item_code, i.item_name FROM sales_return_items sri JOIN items i ON i.id = sri.item_id WHERE sri.sales_return_id = ?`).all(req.params.id);
  res.json({ ...sr, items });
});

router.post('/sales-returns', requireRole('manager', 'sales'), (req, res) => {
  const b = req.body;
  if (!b.customer_id) return res.status(400).json({ error: 'Customer is required' });
  if (!Array.isArray(b.items) || b.items.length === 0) return res.status(400).json({ error: 'At least one item is required' });
  const date = b.date || new Date().toISOString().slice(0, 10);

  const txn = db.transaction(() => {
    const returnNo = nextCode(db, 'sales_returns', 'return_no', 'SRET');
    let total = 0;
    const lines = b.items.map(it => {
      const qty = Number(it.quantity), rate = Number(it.rate);
      if (qty <= 0) throw new Error('Quantity must be greater than zero');
      const lineTotal = qty * rate;
      total += lineTotal;
      return { ...it, qty, rate, lineTotal };
    });
    const refund = Number(b.refund_amount) || 0;

    const info = db.prepare(`INSERT INTO sales_returns (return_no, date, sale_id, customer_id, total, refund_amount, payment_method, notes)
      VALUES (?,?,?,?,?,?,?,?)`).run(returnNo, date, b.sale_id || null, b.customer_id, total, refund, b.payment_method || 'cash', b.notes || '');
    const returnId = info.lastInsertRowid;

    const insItem = db.prepare(`INSERT INTO sales_return_items (sales_return_id, item_id, quantity, rate, total) VALUES (?,?,?,?,?)`);
    for (const it of lines) {
      insItem.run(returnId, it.item_id, it.qty, it.rate, it.lineTotal);
      // increase stock (goods returned to shop)
      moveStock(db, { itemId: it.item_id, date, type: 'sales_return', reference: returnNo, qtyIn: it.qty });
    }

    // customer balance decreases (credit)
    addCustomerLedgerEntry(db, { customerId: b.customer_id, date, reference: returnNo, description: `Sales Return ${returnNo}`, credit: total });
    if (refund > 0 && (b.payment_method || 'cash') === 'cash') {
      addCashTransaction(db, { date, type: 'sales_return', description: `Refund for Sales Return ${returnNo}`, reference: returnNo, cashOut: refund });
    }

    return { id: returnId, return_no: returnNo, total };
  });

  try { res.json(txn()); } catch (e) { res.status(400).json({ error: e.message }); }
});

module.exports = router;
