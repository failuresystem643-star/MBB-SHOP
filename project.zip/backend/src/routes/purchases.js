const express = require('express');
const { db } = require('../db/init');
const { authRequired, requireRole } = require('../middleware/auth');
const { nextCode } = require('../utils/generateCode');
const { moveStock, addSupplierLedgerEntry, addCashTransaction } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  const { from, to, supplier_id, q } = req.query;
  let sql = `SELECT p.*, s.name as supplier_name FROM purchases p JOIN suppliers s ON s.id = p.supplier_id WHERE 1=1`;
  const params = [];
  if (from) { sql += ' AND p.date >= ?'; params.push(from); }
  if (to) { sql += ' AND p.date <= ?'; params.push(to); }
  if (supplier_id) { sql += ' AND p.supplier_id = ?'; params.push(supplier_id); }
  if (q) { sql += ' AND (p.purchase_no LIKE ? OR s.name LIKE ?)'; params.push(`%${q}%`, `%${q}%`); }
  sql += ' ORDER BY p.id DESC';
  res.json(db.prepare(sql).all(...params));
});

router.get('/:id', (req, res) => {
  const purchase = db.prepare(`SELECT p.*, s.name as supplier_name FROM purchases p JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ?`).get(req.params.id);
  if (!purchase) return res.status(404).json({ error: 'Purchase not found' });
  const items = db.prepare(`SELECT pi.*, i.item_code, i.item_name, i.unit_id, u.name as unit_name
    FROM purchase_items pi JOIN items i ON i.id = pi.item_id LEFT JOIN units u ON u.id = i.unit_id WHERE pi.purchase_id = ?`).all(req.params.id);
  res.json({ ...purchase, items });
});

router.post('/', requireRole('manager'), (req, res) => {
  const b = req.body;
  if (!b.supplier_id) return res.status(400).json({ error: 'Supplier is required' });
  if (!Array.isArray(b.items) || b.items.length === 0) return res.status(400).json({ error: 'At least one item is required' });
  for (const it of b.items) {
    if (!it.item_id || Number(it.quantity) <= 0) return res.status(400).json({ error: 'Each item must have a valid quantity greater than zero' });
  }

  const date = b.date || new Date().toISOString().slice(0, 10);
  const paymentMethod = b.payment_method || 'cash';
  const paid = Number(b.paid_amount) || 0;

  const txn = db.transaction(() => {
    const purchaseNo = nextCode(db, 'purchases', 'purchase_no', 'PUR');
    let subtotal = 0;
    const lineTotals = b.items.map(it => {
      const qty = Number(it.quantity), rate = Number(it.rate), disc = Number(it.discount) || 0, tax = Number(it.tax) || 0;
      const total = (qty * rate) - disc + tax;
      subtotal += total;
      return { ...it, qty, rate, disc, tax, total };
    });
    const discount = Number(b.discount) || 0;
    const tax = Number(b.tax) || 0;
    const total = subtotal - discount + tax;
    const remaining = Math.max(total - paid, 0);

    const info = db.prepare(`INSERT INTO purchases
      (purchase_no, date, supplier_id, subtotal, discount, tax, total, paid_amount, remaining_amount, payment_method, notes, created_by)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(purchaseNo, date, b.supplier_id, subtotal, discount, tax, total, paid, remaining, paymentMethod, b.notes || '', req.user.id);
    const purchaseId = info.lastInsertRowid;

    const insItem = db.prepare(`INSERT INTO purchase_items (purchase_id, item_id, quantity, rate, discount, tax, total) VALUES (?,?,?,?,?,?,?)`);
    for (const it of lineTotals) {
      insItem.run(purchaseId, it.item_id, it.qty, it.rate, it.disc, it.tax, it.total);
      // 1. increase stock
      moveStock(db, { itemId: it.item_id, date, type: 'purchase', reference: purchaseNo, qtyIn: it.qty });
      // update item purchase price/history (latest cost)
      db.prepare('UPDATE items SET purchase_price = ? WHERE id = ?').run(it.rate, it.item_id);
    }

    // 2. update supplier ledger: purchase increases payable (credit)
    addSupplierLedgerEntry(db, { supplierId: b.supplier_id, date, reference: purchaseNo, description: `Purchase Invoice ${purchaseNo}`, credit: total });
    if (paid > 0) {
      addSupplierLedgerEntry(db, { supplierId: b.supplier_id, date, reference: purchaseNo, description: `Payment against ${purchaseNo}`, debit: paid });
    }

    // 3. cash book - if paid amount > 0 and method is cash, cash out
    if (paid > 0 && paymentMethod === 'cash') {
      addCashTransaction(db, { date, type: 'purchase', description: `Purchase ${purchaseNo}`, reference: purchaseNo, cashOut: paid });
    }

    return { id: purchaseId, purchase_no: purchaseNo, total, remaining };
  });

  try {
    const result = txn();
    res.json(result);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.post('/:id/void', requireRole('manager'), (req, res) => {
  const purchase = db.prepare('SELECT * FROM purchases WHERE id = ?').get(req.params.id);
  if (!purchase) return res.status(404).json({ error: 'Purchase not found' });
  if (purchase.status === 'void') return res.status(400).json({ error: 'Already voided' });

  const txn = db.transaction(() => {
    const items = db.prepare('SELECT * FROM purchase_items WHERE purchase_id = ?').all(req.params.id);
    const date = new Date().toISOString().slice(0, 10);
    for (const it of items) {
      moveStock(db, { itemId: it.item_id, date, type: 'adjustment', reference: `VOID-${purchase.purchase_no}`, qtyOut: it.quantity });
    }
    addSupplierLedgerEntry(db, { supplierId: purchase.supplier_id, date, reference: purchase.purchase_no, description: `Void Purchase ${purchase.purchase_no}`, debit: purchase.total });
    if (purchase.paid_amount > 0 && purchase.payment_method === 'cash') {
      addCashTransaction(db, { date, type: 'purchase', description: `Void Purchase ${purchase.purchase_no}`, reference: purchase.purchase_no, cashIn: purchase.paid_amount });
    }
    db.prepare("UPDATE purchases SET status = 'void' WHERE id = ?").run(req.params.id);
  });

  try { txn(); res.json({ success: true }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

module.exports = router;
