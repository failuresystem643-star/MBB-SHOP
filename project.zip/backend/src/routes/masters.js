const express = require('express');
const { db } = require('../db/init');
const { authRequired } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

// generic factory for simple master tables: categories, brands, units, expense_categories
function makeMasterRouter(table) {
  const r = express.Router();

  r.get('/', (req, res) => {
    res.json(db.prepare(`SELECT * FROM ${table} ORDER BY name`).all());
  });

  r.post('/', (req, res) => {
    const { name } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required' });
    const exists = db.prepare(`SELECT id FROM ${table} WHERE name = ?`).get(name.trim());
    if (exists) return res.status(400).json({ error: `${name} already exists` });
    const info = db.prepare(`INSERT INTO ${table} (name) VALUES (?)`).run(name.trim());
    res.json({ id: info.lastInsertRowid, name: name.trim() });
  });

  r.put('/:id', (req, res) => {
    const { name } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ error: 'Name is required' });
    db.prepare(`UPDATE ${table} SET name = ? WHERE id = ?`).run(name.trim(), req.params.id);
    res.json({ success: true });
  });

  r.delete('/:id', (req, res) => {
    // Prevent deletion if referenced (basic safety check for categories/brands/units)
    try {
      db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(req.params.id);
      res.json({ success: true });
    } catch (e) {
      res.status(400).json({ error: 'Cannot delete: this record is used elsewhere' });
    }
  });

  return r;
}

router.use('/categories', makeMasterRouter('categories'));
router.use('/brands', makeMasterRouter('brands'));
router.use('/units', makeMasterRouter('units'));
router.use('/expense-categories', makeMasterRouter('expense_categories'));

module.exports = router;
