const express = require('express');
const { db } = require('../db/init');
const { authRequired } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

const ITEM_SELECT = `
  SELECT i.*, c.name as category_name, b.name as brand_name, u.name as unit_name, s.name as supplier_name
  FROM items i
  LEFT JOIN categories c ON c.id = i.category_id
  LEFT JOIN brands b ON b.id = i.brand_id
  LEFT JOIN units u ON u.id = i.unit_id
  LEFT JOIN suppliers s ON s.id = i.supplier_id
`;

// List / search items
router.get('/', (req, res) => {
  const { q, category_id, status, low_stock } = req.query;
  let sql = ITEM_SELECT + ' WHERE 1=1';
  const params = [];
  if (q) {
    sql += ' AND (i.item_code LIKE ? OR i.item_name LIKE ?)';
    params.push(`%${q}%`, `%${q}%`);
  }
  if (category_id) { sql += ' AND i.category_id = ?'; params.push(category_id); }
  if (status) { sql += ' AND i.status = ?'; params.push(status); }
  if (low_stock === 'true') { sql += ' AND i.current_stock <= i.min_stock_level'; }
  sql += ' ORDER BY i.item_name';
  res.json(db.prepare(sql).all(...params));
});

// Quick lookup by exact/partial item code - used for autocomplete in Sales/Purchase
router.get('/lookup/:code', (req, res) => {
  const code = req.params.code;
  const exact = db.prepare(ITEM_SELECT + ' WHERE i.item_code = ?').get(code);
  if (exact) return res.json({ exact, suggestions: [] });
  const suggestions = db.prepare(ITEM_SELECT + ' WHERE i.item_code LIKE ? OR i.item_name LIKE ? LIMIT 10')
    .all(`%${code}%`, `%${code}%`);
  res.json({ exact: null, suggestions });
});

router.get('/:id', (req, res) => {
  const item = db.prepare(ITEM_SELECT + ' WHERE i.id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  res.json(item);
});

router.post('/', (req, res) => {
  const b = req.body;
  if (!b.item_code || !b.item_name) return res.status(400).json({ error: 'Item Code and Item Name are required' });
  const exists = db.prepare('SELECT id FROM items WHERE item_code = ?').get(b.item_code.trim());
  if (exists) return res.status(400).json({ error: `Item Code "${b.item_code}" already exists` });

  const opening = Number(b.opening_stock) || 0;
  const info = db.prepare(`INSERT INTO items
    (item_code, item_name, category_id, brand_id, unit_id, purchase_price, sale_price, min_stock_level, opening_stock, current_stock, supplier_id, description, status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(b.item_code.trim(), b.item_name.trim(), b.category_id || null, b.brand_id || null, b.unit_id || null,
      Number(b.purchase_price) || 0, Number(b.sale_price) || 0, Number(b.min_stock_level) || 0,
      opening, opening, b.supplier_id || null, b.description || '', b.status || 'active');

  const itemId = info.lastInsertRowid;
  if (opening > 0) {
    db.prepare(`INSERT INTO stock_movements (item_id, date, type, reference, qty_in, qty_out, balance) VALUES (?,?,?,?,?,?,?)`)
      .run(itemId, new Date().toISOString().slice(0,10), 'opening', 'Opening Stock', opening, 0, opening);
  }
  res.json({ id: itemId });
});

router.put('/:id', (req, res) => {
  const b = req.body;
  const item = db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Item not found' });
  if (b.item_code && b.item_code.trim() !== item.item_code) {
    const dup = db.prepare('SELECT id FROM items WHERE item_code = ? AND id != ?').get(b.item_code.trim(), req.params.id);
    if (dup) return res.status(400).json({ error: `Item Code "${b.item_code}" already exists` });
  }
  db.prepare(`UPDATE items SET item_code=?, item_name=?, category_id=?, brand_id=?, unit_id=?,
    purchase_price=?, sale_price=?, min_stock_level=?, supplier_id=?, description=?, status=?, updated_at=datetime('now')
    WHERE id=?`).run(
    b.item_code?.trim() ?? item.item_code, b.item_name?.trim() ?? item.item_name,
    b.category_id ?? item.category_id, b.brand_id ?? item.brand_id, b.unit_id ?? item.unit_id,
    b.purchase_price ?? item.purchase_price, b.sale_price ?? item.sale_price, b.min_stock_level ?? item.min_stock_level,
    b.supplier_id ?? item.supplier_id, b.description ?? item.description, b.status ?? item.status, req.params.id
  );
  res.json({ success: true });
});

router.delete('/:id', (req, res) => {
  const used = db.prepare('SELECT id FROM sale_items WHERE item_id = ? UNION SELECT id FROM purchase_items WHERE item_id = ? LIMIT 1')
    .get(req.params.id, req.params.id);
  if (used) return res.status(400).json({ error: 'Cannot delete: item has transaction history. Set status to Inactive instead.' });
  db.prepare('DELETE FROM stock_movements WHERE item_id = ?').run(req.params.id);
  db.prepare('DELETE FROM items WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// Reset/remove demo items specifically
router.delete('/demo/reset', (req, res) => {
  const demoItems = db.prepare('SELECT id FROM items WHERE is_demo = 1').all();
  const used = db.prepare('SELECT COUNT(*) c FROM sale_items si JOIN items i ON i.id = si.item_id WHERE i.is_demo = 1').get().c
    + db.prepare('SELECT COUNT(*) c FROM purchase_items pi JOIN items i ON i.id = pi.item_id WHERE i.is_demo = 1').get().c;
  if (used > 0) return res.status(400).json({ error: 'Cannot remove demo items: some have transaction history. Void/delete those transactions first.' });
  db.prepare('DELETE FROM stock_movements WHERE item_id IN (SELECT id FROM items WHERE is_demo = 1)').run();
  db.prepare('DELETE FROM items WHERE is_demo = 1').run();
  db.prepare('DELETE FROM categories WHERE is_demo = 1').run();
  db.prepare('DELETE FROM brands WHERE is_demo = 1').run();
  db.prepare('DELETE FROM units WHERE is_demo = 1').run();
  db.prepare('DELETE FROM customers WHERE is_demo = 1 AND id NOT IN (SELECT DISTINCT customer_id FROM sales)').run();
  db.prepare('DELETE FROM suppliers WHERE is_demo = 1 AND id NOT IN (SELECT DISTINCT supplier_id FROM purchases)').run();
  res.json({ success: true, removed: demoItems.length });
});

module.exports = router;
