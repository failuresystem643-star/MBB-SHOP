const express = require('express');
const { db } = require('../db/init');
const { authRequired } = require('../middleware/auth');
const { getCustomerBalance, getSupplierBalance } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

function dateFilter(from, to, col = 'date') {
  let sql = '';
  const params = [];
  if (from) { sql += ` AND ${col} >= ?`; params.push(from); }
  if (to) { sql += ` AND ${col} <= ?`; params.push(to); }
  return { sql, params };
}

router.get('/sales', (req, res) => {
  const { from, to } = req.query;
  const { sql: df, params } = dateFilter(from, to, 's.date');
  const rows = db.prepare(`SELECT s.*, c.name as customer_name FROM sales s JOIN customers c ON c.id = s.customer_id WHERE s.status='active' ${df} ORDER BY s.date`).all(...params);
  const totals = rows.reduce((a, r) => ({ total: a.total + r.total, paid: a.paid + r.paid_amount, remaining: a.remaining + r.remaining_amount }), { total: 0, paid: 0, remaining: 0 });
  res.json({ rows, totals });
});

router.get('/sales-by-item', (req, res) => {
  const { from, to } = req.query;
  const { sql: df, params } = dateFilter(from, to, 's.date');
  const rows = db.prepare(`
    SELECT i.item_code, i.item_name, SUM(si.quantity) as qty_sold, SUM(si.total) as total_sales, SUM(si.quantity*si.cost_rate) as total_cost
    FROM sale_items si JOIN sales s ON s.id = si.sale_id JOIN items i ON i.id = si.item_id
    WHERE s.status='active' ${df}
    GROUP BY si.item_id ORDER BY total_sales DESC
  `).all(...params);
  res.json(rows.map(r => ({ ...r, profit: r.total_sales - r.total_cost })));
});

router.get('/sales-by-customer', (req, res) => {
  const { from, to } = req.query;
  const { sql: df, params } = dateFilter(from, to, 's.date');
  const rows = db.prepare(`
    SELECT c.id, c.name, COUNT(s.id) as invoice_count, SUM(s.total) as total_sales, SUM(s.paid_amount) as total_paid, SUM(s.remaining_amount) as total_due
    FROM sales s JOIN customers c ON c.id = s.customer_id WHERE s.status='active' ${df}
    GROUP BY s.customer_id ORDER BY total_sales DESC
  `).all(...params);
  res.json(rows);
});

router.get('/purchases', (req, res) => {
  const { from, to } = req.query;
  const { sql: df, params } = dateFilter(from, to, 'p.date');
  const rows = db.prepare(`SELECT p.*, s.name as supplier_name FROM purchases p JOIN suppliers s ON s.id = p.supplier_id WHERE p.status='active' ${df} ORDER BY p.date`).all(...params);
  const totals = rows.reduce((a, r) => ({ total: a.total + r.total, paid: a.paid + r.paid_amount, remaining: a.remaining + r.remaining_amount }), { total: 0, paid: 0, remaining: 0 });
  res.json({ rows, totals });
});

router.get('/purchases-by-supplier', (req, res) => {
  const { from, to } = req.query;
  const { sql: df, params } = dateFilter(from, to, 'p.date');
  const rows = db.prepare(`
    SELECT s.id, s.name, COUNT(p.id) as invoice_count, SUM(p.total) as total_purchases, SUM(p.paid_amount) as total_paid, SUM(p.remaining_amount) as total_due
    FROM purchases p JOIN suppliers s ON s.id = p.supplier_id WHERE p.status='active' ${df}
    GROUP BY p.supplier_id ORDER BY total_purchases DESC
  `).all(...params);
  res.json(rows);
});

router.get('/stock', (req, res) => {
  const rows = db.prepare(`SELECT i.item_code, i.item_name, c.name as category_name, i.current_stock, i.purchase_price, i.sale_price,
    (i.current_stock * i.purchase_price) as stock_value, i.min_stock_level,
    CASE WHEN i.current_stock <= 0 THEN 'Out of Stock' WHEN i.current_stock <= i.min_stock_level THEN 'Low Stock' ELSE 'OK' END as stock_status
    FROM items i LEFT JOIN categories c ON c.id = i.category_id WHERE i.status='active' ORDER BY i.item_name`).all();
  res.json(rows);
});

router.get('/customer-outstanding', (req, res) => {
  const customers = db.prepare('SELECT * FROM customers').all();
  const rows = customers.map(c => ({ ...c, balance: getCustomerBalance(db, c.id) })).filter(c => c.balance !== 0);
  res.json(rows);
});

router.get('/supplier-outstanding', (req, res) => {
  const suppliers = db.prepare('SELECT * FROM suppliers').all();
  const rows = suppliers.map(s => ({ ...s, balance: getSupplierBalance(db, s.id) })).filter(s => s.balance !== 0);
  res.json(rows);
});

router.get('/expenses', (req, res) => {
  const { from, to } = req.query;
  const { sql: df, params } = dateFilter(from, to, 'e.date');
  const rows = db.prepare(`SELECT e.*, ec.name as category_name FROM expenses e LEFT JOIN expense_categories ec ON ec.id = e.category_id WHERE e.status='active' ${df} ORDER BY e.date`).all(...params);
  const total = rows.reduce((a, r) => a + r.amount, 0);
  res.json({ rows, total });
});

router.get('/profit-summary', (req, res) => {
  const { from, to } = req.query;
  const { sql: df, params } = dateFilter(from, to, 's.date');
  const sales = db.prepare(`SELECT COALESCE(SUM(si.total),0) as gross_sales, COALESCE(SUM(si.quantity*si.cost_rate),0) as cogs
    FROM sale_items si JOIN sales s ON s.id = si.sale_id WHERE s.status='active' ${df}`).get(...params);
  const { sql: ef, params: eparams } = dateFilter(from, to, 'e.date');
  const expenses = db.prepare(`SELECT COALESCE(SUM(e.amount),0) as total FROM expenses e WHERE e.status='active' ${ef}`).get(...eparams);
  const grossProfit = sales.gross_sales - sales.cogs;
  const netProfit = grossProfit - expenses.total;
  res.json({
    gross_sales: sales.gross_sales,
    cost_of_goods_sold: sales.cogs,
    gross_profit: grossProfit,
    total_expenses: expenses.total,
    net_profit: netProfit,
    note: 'This is an estimated profit figure based on recorded cost rates at time of sale. Reconcile with finalized accounting records for statutory reporting.'
  });
});

router.get('/purchase-returns', (req, res) => {
  const { from, to } = req.query;
  const { sql: df, params } = dateFilter(from, to, 'pr.date');
  const rows = db.prepare(`SELECT pr.*, s.name as supplier_name FROM purchase_returns pr JOIN suppliers s ON s.id = pr.supplier_id WHERE pr.status='active' ${df} ORDER BY pr.date`).all(...params);
  res.json(rows);
});

router.get('/sales-returns', (req, res) => {
  const { from, to } = req.query;
  const { sql: df, params } = dateFilter(from, to, 'sr.date');
  const rows = db.prepare(`SELECT sr.*, c.name as customer_name FROM sales_returns sr JOIN customers c ON c.id = sr.customer_id WHERE sr.status='active' ${df} ORDER BY sr.date`).all(...params);
  res.json(rows);
});

module.exports = router;
