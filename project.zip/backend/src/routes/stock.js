const express = require('express');
const { db } = require('../db/init');
const { authRequired } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

router.get('/summary', (req, res) => {
  const items = db.prepare(`SELECT i.*, c.name as category_name, u.name as unit_name FROM items i
    LEFT JOIN categories c ON c.id = i.category_id LEFT JOIN units u ON u.id = i.unit_id WHERE i.status='active'`).all();
  const totalValue = items.reduce((sum, i) => sum + (i.current_stock * i.purchase_price), 0);
  const lowStock = items.filter(i => i.current_stock <= i.min_stock_level && i.current_stock > 0);
  const outOfStock = items.filter(i => i.current_stock <= 0);
  res.json({
    items,
    total_stock_value: totalValue,
    low_stock_count: lowStock.length,
    out_of_stock_count: outOfStock.length,
    low_stock_items: lowStock,
    out_of_stock_items: outOfStock
  });
});

router.get('/movement/:itemId', (req, res) => {
  const { from, to } = req.query;
  let sql = 'SELECT * FROM stock_movements WHERE item_id = ?';
  const params = [req.params.itemId];
  if (from) { sql += ' AND date >= ?'; params.push(from); }
  if (to) { sql += ' AND date <= ?'; params.push(to); }
  sql += ' ORDER BY id';
  const item = db.prepare('SELECT item_code, item_name FROM items WHERE id = ?').get(req.params.itemId);
  res.json({ item, movements: db.prepare(sql).all(...params) });
});

module.exports = router;
