const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../db/init');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

router.get('/', requireRole('admin'), (req, res) => {
  const users = db.prepare('SELECT id, username, full_name, role, is_active, created_at FROM users ORDER BY id').all();
  res.json(users);
});

router.post('/', requireRole('admin'), (req, res) => {
  const { username, password, full_name, role } = req.body;
  if (!username || !password || !role) return res.status(400).json({ error: 'Username, password and role are required' });
  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) return res.status(400).json({ error: 'Username already exists' });
  const hash = bcrypt.hashSync(password, 10);
  const info = db.prepare('INSERT INTO users (username, password_hash, full_name, role) VALUES (?,?,?,?)')
    .run(username, hash, full_name || '', role);
  res.json({ id: info.lastInsertRowid });
});

router.put('/:id', requireRole('admin'), (req, res) => {
  const { full_name, role, is_active, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  db.prepare('UPDATE users SET full_name = ?, role = ?, is_active = ? WHERE id = ?')
    .run(full_name ?? user.full_name, role ?? user.role, is_active === undefined ? user.is_active : (is_active ? 1 : 0), req.params.id);
  if (password) {
    const hash = bcrypt.hashSync(password, 10);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, req.params.id);
  }
  res.json({ success: true });
});

module.exports = router;
