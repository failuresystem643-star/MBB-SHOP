const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const { db, DB_PATH, DATA_DIR } = require('../db/init');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

const BACKUP_DIR = path.join(__dirname, '..', '..', 'backups');
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

const upload = multer({ dest: path.join(BACKUP_DIR, 'tmp') });

router.get('/list', requireRole('admin'), (req, res) => {
  const files = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.endsWith('.db'))
    .map(f => {
      const stat = fs.statSync(path.join(BACKUP_DIR, f));
      return { name: f, size: stat.size, created_at: stat.mtime };
    })
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const lastBackup = db.prepare("SELECT value FROM settings WHERE key='last_backup'").get();
  res.json({ files, last_backup: lastBackup ? lastBackup.value : null });
});

router.post('/create', requireRole('admin'), (req, res) => {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupFile = path.join(BACKUP_DIR, `shop-backup-${timestamp}.db`);
  try {
    db.backup(backupFile)
      .then(() => {
        db.prepare(`INSERT OR REPLACE INTO settings (key, value) VALUES ('last_backup', ?)`).run(new Date().toISOString());
        res.json({ success: true, file: path.basename(backupFile) });
      })
      .catch(err => res.status(500).json({ error: 'Backup failed: ' + err.message }));
  } catch (e) {
    res.status(500).json({ error: 'Backup failed: ' + e.message });
  }
});

router.get('/download/:filename', requireRole('admin'), (req, res) => {
  const filePath = path.join(BACKUP_DIR, req.params.filename);
  if (!filePath.startsWith(BACKUP_DIR) || !fs.existsSync(filePath)) return res.status(404).json({ error: 'Backup file not found' });
  res.download(filePath);
});

// Restore: upload a .db backup file. Requires server restart after restore to reload the connection safely.
router.post('/restore', requireRole('admin'), upload.single('backup'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No backup file uploaded' });
  try {
    // Safety: keep a pre-restore snapshot first
    const safetyFile = path.join(BACKUP_DIR, `pre-restore-safety-${Date.now()}.db`);
    fs.copyFileSync(DB_PATH, safetyFile);

    db.close();
    fs.copyFileSync(req.file.path, DB_PATH);
    fs.unlinkSync(req.file.path);

    res.json({ success: true, message: 'Restore complete. Please restart the server to load the restored data.' });
    setTimeout(() => process.exit(0), 500); // graceful exit; use a process manager (e.g. pm2 / nssm) to auto-restart
  } catch (e) {
    res.status(500).json({ error: 'Restore failed: ' + e.message });
  }
});

module.exports = router;
