const express = require('express');
const { db } = require('../db/init');
const { authRequired, requireRole } = require('../middleware/auth');
const { nextCode } = require('../utils/generateCode');
const { addCustomerLedgerEntry, addSupplierLedgerEntry, addCashTransaction } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

// ---- Customer Payments (money received FROM customer) ----
router.get('/customer-payments', (req, res) => {
  const { customer_id, from, to } = req.query;
  let sql = `SELECT cp.*, c.name as customer_name FROM customer_payments cp JOIN customers c ON c.id = cp.customer_id WHERE 1=1`;
  const params = [];
  if (customer_id) { sql += ' AND cp.customer_id = ?'; params.push(customer_id); }
  if (from) { sql += ' AND cp.date >= ?'; params.push(from); }
  if (to) { sql += ' AND cp.date <= ?'; params.push(to); }
  sql += ' ORDER BY cp.id DESC';
  res.json(db.prepare(sql).all(...params));
});

router.post('/customer-payments', requireRole('manager', 'sales'), (req, res) => {
  const b = req.body;
  if (!b.customer_id || !(Number(b.amount) > 0)) return res.status(400).json({ error: 'Customer and a valid amount are required' });
  const date = b.date || new Date().toISOString().slice(0, 10);
  const method = b.payment_method || 'cash';

  const txn = db.transaction(() => {
    const paymentNo = nextCode(db, 'customer_payments', 'payment_no', 'CRCT');
    db.prepare(`INSERT INTO customer_payments (payment_no, customer_id, date, amount, payment_method, reference, notes)
      VALUES (?,?,?,?,?,?,?)`).run(paymentNo, b.customer_id, date, b.amount, method, b.reference || '', b.notes || '');
    addCustomerLedgerEntry(db, { customerId: b.customer_id, date, reference: paymentNo, description: `Payment Received (${method})`, credit: Number(b.amount) });
    if (method === 'cash') {
      addCashTransaction(db, { date, type: 'customer_payment', description: `Payment from customer`, reference: paymentNo, cashIn: Number(b.amount) });
    }
    return { payment_no: paymentNo };
  });

  try { res.json(txn()); } catch (e) { res.status(400).json({ error: e.message }); }
});

// ---- Supplier Payments (money paid TO supplier) ----
router.get('/supplier-payments', (req, res) => {
  const { supplier_id, from, to } = req.query;
  let sql = `SELECT sp.*, s.name as supplier_name FROM supplier_payments sp JOIN suppliers s ON s.id = sp.supplier_id WHERE 1=1`;
  const params = [];
  if (supplier_id) { sql += ' AND sp.supplier_id = ?'; params.push(supplier_id); }
  if (from) { sql += ' AND sp.date >= ?'; params.push(from); }
  if (to) { sql += ' AND sp.date <= ?'; params.push(to); }
  sql += ' ORDER BY sp.id DESC';
  res.json(db.prepare(sql).all(...params));
});

router.post('/supplier-payments', requireRole('manager'), (req, res) => {
  const b = req.body;
  if (!b.supplier_id || !(Number(b.amount) > 0)) return res.status(400).json({ error: 'Supplier and a valid amount are required' });
  const date = b.date || new Date().toISOString().slice(0, 10);
  const method = b.payment_method || 'cash';

  const txn = db.transaction(() => {
    const paymentNo = nextCode(db, 'supplier_payments', 'payment_no', 'SPPT');
    db.prepare(`INSERT INTO supplier_payments (payment_no, supplier_id, date, amount, payment_method, reference, notes)
      VALUES (?,?,?,?,?,?,?)`).run(paymentNo, b.supplier_id, date, b.amount, method, b.reference || '', b.notes || '');
    addSupplierLedgerEntry(db, { supplierId: b.supplier_id, date, reference: paymentNo, description: `Payment Made (${method})`, debit: Number(b.amount) });
    if (method === 'cash') {
      addCashTransaction(db, { date, type: 'supplier_payment', description: `Payment to supplier`, reference: paymentNo, cashOut: Number(b.amount) });
    }
    return { payment_no: paymentNo };
  });

  try { res.json(txn()); } catch (e) { res.status(400).json({ error: e.message }); }
});

module.exports = router;
