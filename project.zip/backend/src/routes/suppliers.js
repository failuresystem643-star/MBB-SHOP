const express = require('express');
const { db } = require('../db/init');
const { authRequired } = require('../middleware/auth');
const { nextCode } = require('../utils/generateCode');
const { getSupplierBalance } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  const { q } = req.query;
  let sql = 'SELECT * FROM suppliers WHERE 1=1';
  const params = [];
  if (q) { sql += ' AND (name LIKE ? OR mobile LIKE ? OR supplier_code LIKE ?)'; params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
  sql += ' ORDER BY name';
  const suppliers = db.prepare(sql).all(...params);
  res.json(suppliers.map(s => ({ ...s, current_balance: getSupplierBalance(db, s.id) })));
});

router.get('/:id', (req, res) => {
  const s = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(req.params.id);
  if (!s) return res.status(404).json({ error: 'Supplier not found' });
  const totalPurchases = db.prepare("SELECT COALESCE(SUM(total),0) t FROM purchases WHERE supplier_id = ? AND status='active'").get(req.params.id).t;
  const totalPaid = db.prepare("SELECT COALESCE(SUM(paid_amount),0) t FROM purchases WHERE supplier_id = ? AND status='active'").get(req.params.id).t
    + db.prepare("SELECT COALESCE(SUM(amount),0) t FROM supplier_payments WHERE supplier_id = ? AND status='active'").get(req.params.id).t;
  res.json({ ...s, current_balance: getSupplierBalance(db, req.params.id), total_purchases: totalPurchases, total_paid: totalPaid });
});

router.get('/:id/ledger', (req, res) => {
  const { from, to } = req.query;
  let sql = 'SELECT * FROM supplier_ledger WHERE supplier_id = ?';
  const params = [req.params.id];
  if (from) { sql += ' AND date >= ?'; params.push(from); }
  if (to) { sql += ' AND date <= ?'; params.push(to); }
  sql += ' ORDER BY id';
  res.json(db.prepare(sql).all(...params));
});

router.post('/', (req, res) => {
  const b = req.body;
  if (!b.name || !b.name.trim()) return res.status(400).json({ error: 'Supplier name is required' });
  const code = nextCode(db, 'suppliers', 'supplier_code', 'SUP');
  const info = db.prepare(`INSERT INTO suppliers (supplier_code, name, mobile, address, opening_balance) VALUES (?,?,?,?,?)`)
    .run(code, b.name.trim(), b.mobile || '', b.address || '', Number(b.opening_balance) || 0);
  res.json({ id: info.lastInsertRowid, supplier_code: code });
});

router.put('/:id', (req, res) => {
  const b = req.body;
  const s = db.prepare('SELECT * FROM suppliers WHERE id = ?').get(req.params.id);
  if (!s) return res.status(404).json({ error: 'Supplier not found' });
  db.prepare('UPDATE suppliers SET name=?, mobile=?, address=? WHERE id=?')
    .run(b.name?.trim() ?? s.name, b.mobile ?? s.mobile, b.address ?? s.address, req.params.id);
  res.json({ success: true });
});

router.delete('/:id', (req, res) => {
  const used = db.prepare('SELECT id FROM purchases WHERE supplier_id = ? LIMIT 1').get(req.params.id);
  if (used) return res.status(400).json({ error: 'Cannot delete: supplier has transaction history' });
  db.prepare('DELETE FROM suppliers WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
