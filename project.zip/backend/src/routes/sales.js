const express = require('express');
const { db } = require('../db/init');
const { authRequired, requireRole } = require('../middleware/auth');
const { nextCode } = require('../utils/generateCode');
const { moveStock, getCurrentStock, addCustomerLedgerEntry, addCashTransaction } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  const { from, to, customer_id, q } = req.query;
  let sql = `SELECT s.*, c.name as customer_name FROM sales s JOIN customers c ON c.id = s.customer_id WHERE 1=1`;
  const params = [];
  if (from) { sql += ' AND s.date >= ?'; params.push(from); }
  if (to) { sql += ' AND s.date <= ?'; params.push(to); }
  if (customer_id) { sql += ' AND s.customer_id = ?'; params.push(customer_id); }
  if (q) { sql += ' AND (s.invoice_no LIKE ? OR c.name LIKE ?)'; params.push(`%${q}%`, `%${q}%`); }
  sql += ' ORDER BY s.id DESC';
  res.json(db.prepare(sql).all(...params));
});

router.get('/:id', (req, res) => {
  const sale = db.prepare(`SELECT s.*, c.name as customer_name, c.mobile as customer_mobile, c.address as customer_address
    FROM sales s JOIN customers c ON c.id = s.customer_id WHERE s.id = ?`).get(req.params.id);
  if (!sale) return res.status(404).json({ error: 'Sale not found' });
  const items = db.prepare(`SELECT si.*, i.item_code, i.item_name, u.name as unit_name, b.name as brand_name
    FROM sale_items si JOIN items i ON i.id = si.item_id
    LEFT JOIN units u ON u.id = i.unit_id LEFT JOIN brands b ON b.id = i.brand_id WHERE si.sale_id = ?`).all(req.params.id);
  res.json({ ...sale, items });
});

router.post('/', requireRole('manager', 'sales'), (req, res) => {
  const b = req.body;
  const settings = Object.fromEntries(db.prepare('SELECT key, value FROM settings').all().map(r => [r.key, r.value]));
  const allowNegative = settings.allow_negative_stock === 'true';

  if (!b.customer_id) return res.status(400).json({ error: 'Customer is required' });
  if (!Array.isArray(b.items) || b.items.length === 0) return res.status(400).json({ error: 'At least one item is required' });
  for (const it of b.items) {
    if (!it.item_id || Number(it.quantity) <= 0) return res.status(400).json({ error: 'Each item must have a valid quantity greater than zero' });
  }

  // Stock validation before committing
  if (!allowNegative && !req.body.override_negative_stock) {
    for (const it of b.items) {
      const stock = getCurrentStock(db, it.item_id);
      if (Number(it.quantity) > stock) {
        const item = db.prepare('SELECT item_code, item_name FROM items WHERE id = ?').get(it.item_id);
        return res.status(400).json({ error: `Insufficient stock for ${item?.item_name || it.item_id} (${item?.item_code}). Available: ${stock}` });
      }
    }
  }

  const date = b.date || new Date().toISOString().slice(0, 10);
  const paymentMethod = b.payment_method || 'cash';
  const paid = Number(b.paid_amount) || 0;

  const txn = db.transaction(() => {
    const invoiceNo = nextCode(db, 'sales', 'invoice_no', 'INV');
    let subtotal = 0;
    const lineTotals = b.items.map(it => {
      const qty = Number(it.quantity), rate = Number(it.rate), disc = Number(it.discount) || 0, tax = Number(it.tax) || 0;
      const total = (qty * rate) - disc + tax;
      subtotal += total;
      const item = db.prepare('SELECT purchase_price FROM items WHERE id = ?').get(it.item_id);
      return { ...it, qty, rate, disc, tax, total, cost_rate: item ? item.purchase_price : 0 };
    });
    const discount = Number(b.discount) || 0;
    const tax = Number(b.tax) || 0;
    const total = subtotal - discount + tax;
    const remaining = Math.max(total - paid, 0);

    const info = db.prepare(`INSERT INTO sales
      (invoice_no, date, customer_id, subtotal, discount, tax, total, paid_amount, remaining_amount, payment_method, notes, created_by)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(invoiceNo, date, b.customer_id, subtotal, discount, tax, total, paid, remaining, paymentMethod, b.notes || '', req.user.id);
    const saleId = info.lastInsertRowid;

    const insItem = db.prepare(`INSERT INTO sale_items (sale_id, item_id, quantity, rate, cost_rate, discount, tax, total) VALUES (?,?,?,?,?,?,?,?)`);
    for (const it of lineTotals) {
      insItem.run(saleId, it.item_id, it.qty, it.rate, it.cost_rate, it.disc, it.tax, it.total);
      // 1. decrease stock
      moveStock(db, { itemId: it.item_id, date, type: 'sale', reference: invoiceNo, qtyOut: it.qty });
    }

    // 2. update customer ledger: sale increases receivable (debit)
    addCustomerLedgerEntry(db, { customerId: b.customer_id, date, reference: invoiceNo, description: `Sale Invoice ${invoiceNo}`, debit: total });
    if (paid > 0) {
      addCustomerLedgerEntry(db, { customerId: b.customer_id, date, reference: invoiceNo, description: `Payment against ${invoiceNo}`, credit: paid });
    }

    // 3. cash book
    if (paid > 0 && paymentMethod === 'cash') {
      addCashTransaction(db, { date, type: 'sale', description: `Sale ${invoiceNo}`, reference: invoiceNo, cashIn: paid });
    }

    return { id: saleId, invoice_no: invoiceNo, total, remaining };
  });

  try {
    const result = txn();
    res.json(result);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.post('/:id/void', requireRole('manager'), (req, res) => {
  const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(req.params.id);
  if (!sale) return res.status(404).json({ error: 'Sale not found' });
  if (sale.status === 'void') return res.status(400).json({ error: 'Already voided' });

  const txn = db.transaction(() => {
    const items = db.prepare('SELECT * FROM sale_items WHERE sale_id = ?').all(req.params.id);
    const date = new Date().toISOString().slice(0, 10);
    for (const it of items) {
      moveStock(db, { itemId: it.item_id, date, type: 'adjustment', reference: `VOID-${sale.invoice_no}`, qtyIn: it.quantity });
    }
    addCustomerLedgerEntry(db, { customerId: sale.customer_id, date, reference: sale.invoice_no, description: `Void Sale ${sale.invoice_no}`, credit: sale.total });
    if (sale.paid_amount > 0 && sale.payment_method === 'cash') {
      addCashTransaction(db, { date, type: 'sale', description: `Void Sale ${sale.invoice_no}`, reference: sale.invoice_no, cashOut: sale.paid_amount });
    }
    db.prepare("UPDATE sales SET status = 'void' WHERE id = ?").run(req.params.id);
  });

  try { txn(); res.json({ success: true }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

module.exports = router;
