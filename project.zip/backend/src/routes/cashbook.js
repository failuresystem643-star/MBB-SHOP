const express = require('express');
const { db } = require('../db/init');
const { authRequired, requireRole } = require('../middleware/auth');
const { nextCode } = require('../utils/generateCode');
const { getCashBalance } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  const { from, to, type } = req.query;
  let sql = 'SELECT * FROM cash_transactions WHERE 1=1';
  const params = [];
  if (from) { sql += ' AND date >= ?'; params.push(from); }
  if (to) { sql += ' AND date <= ?'; params.push(to); }
  if (type) { sql += ' AND type = ?'; params.push(type); }
  sql += ' ORDER BY id';
  const rows = db.prepare(sql).all(...params);

  let running = 0;
  // compute running balance from the very start regardless of filter
  const openingBefore = from
    ? db.prepare('SELECT COALESCE(SUM(cash_in),0) i, COALESCE(SUM(cash_out),0) o FROM cash_transactions WHERE date < ?').get(from)
    : { i: 0, o: 0 };
  running = openingBefore.i - openingBefore.o;

  const withBalance = rows.map(r => {
    running += r.cash_in - r.cash_out;
    return { ...r, balance: running };
  });

  res.json({ transactions: withBalance, current_balance: getCashBalance(db), opening_before_range: openingBefore.i - openingBefore.o });
});

// Manual "Other Income" / "Other Payment" entry (admin/manager only)
router.post('/manual', requireRole('manager'), (req, res) => {
  const b = req.body;
  const cashIn = Number(b.cash_in) || 0;
  const cashOut = Number(b.cash_out) || 0;
  if (cashIn <= 0 && cashOut <= 0) return res.status(400).json({ error: 'Enter a cash-in or cash-out amount' });
  const date = b.date || new Date().toISOString().slice(0, 10);
  const txnNo = nextCode(db, 'cash_transactions', 'txn_no', 'CT');
  db.prepare(`INSERT INTO cash_transactions (txn_no, date, type, description, reference, cash_in, cash_out)
    VALUES (?,?,?,?,?,?,?)`).run(txnNo, date, 'other', b.description || 'Manual Entry', b.reference || '-', cashIn, cashOut);
  res.json({ txn_no: txnNo });
});

module.exports = router;
