const express = require('express');
const { db } = require('../db/init');
const { authRequired } = require('../middleware/auth');
const { nextCode } = require('../utils/generateCode');
const { getCustomerBalance } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  const { q } = req.query;
  let sql = 'SELECT * FROM customers WHERE 1=1';
  const params = [];
  if (q) { sql += ' AND (name LIKE ? OR mobile LIKE ? OR customer_code LIKE ?)'; params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
  sql += ' ORDER BY name';
  const customers = db.prepare(sql).all(...params);
  const withBalances = customers.map(c => ({ ...c, current_balance: getCustomerBalance(db, c.id) }));
  res.json(withBalances);
});

router.get('/:id', (req, res) => {
  const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Customer not found' });
  const totalSales = db.prepare("SELECT COALESCE(SUM(total),0) t FROM sales WHERE customer_id = ? AND status='active'").get(req.params.id).t;
  const totalPaid = db.prepare("SELECT COALESCE(SUM(paid_amount),0) t FROM sales WHERE customer_id = ? AND status='active'").get(req.params.id).t
    + db.prepare("SELECT COALESCE(SUM(amount),0) t FROM customer_payments WHERE customer_id = ? AND status='active'").get(req.params.id).t;
  res.json({ ...c, current_balance: getCustomerBalance(db, req.params.id), total_sales: totalSales, total_paid: totalPaid });
});

router.get('/:id/ledger', (req, res) => {
  const { from, to } = req.query;
  let sql = 'SELECT * FROM customer_ledger WHERE customer_id = ?';
  const params = [req.params.id];
  if (from) { sql += ' AND date >= ?'; params.push(from); }
  if (to) { sql += ' AND date <= ?'; params.push(to); }
  sql += ' ORDER BY id';
  res.json(db.prepare(sql).all(...params));
});

router.post('/', (req, res) => {
  const b = req.body;
  if (!b.name || !b.name.trim()) return res.status(400).json({ error: 'Customer name is required' });
  const code = nextCode(db, 'customers', 'customer_code', 'CUS');
  const info = db.prepare(`INSERT INTO customers (customer_code, name, mobile, address, opening_balance) VALUES (?,?,?,?,?)`)
    .run(code, b.name.trim(), b.mobile || '', b.address || '', Number(b.opening_balance) || 0);
  res.json({ id: info.lastInsertRowid, customer_code: code });
});

router.put('/:id', (req, res) => {
  const b = req.body;
  const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Customer not found' });
  db.prepare('UPDATE customers SET name=?, mobile=?, address=? WHERE id=?')
    .run(b.name?.trim() ?? c.name, b.mobile ?? c.mobile, b.address ?? c.address, req.params.id);
  res.json({ success: true });
});

router.delete('/:id', (req, res) => {
  const used = db.prepare('SELECT id FROM sales WHERE customer_id = ? LIMIT 1').get(req.params.id);
  if (used) return res.status(400).json({ error: 'Cannot delete: customer has transaction history' });
  db.prepare('DELETE FROM customers WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

module.exports = router;
