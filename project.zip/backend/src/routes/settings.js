const express = require('express');
const { db } = require('../db/init');
const { authRequired, requireRole } = require('../middleware/auth');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  res.json(Object.fromEntries(rows.map(r => [r.key, r.value])));
});

router.put('/', requireRole('admin'), (req, res) => {
  const upsert = db.prepare(`INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`);
  const txn = db.transaction((entries) => { for (const [k, v] of entries) upsert.run(k, String(v)); });
  txn(Object.entries(req.body));
  res.json({ success: true });
});

module.exports = router;
