const express = require('express');
const { db } = require('../db/init');
const { authRequired, requireRole } = require('../middleware/auth');
const { nextCode } = require('../utils/generateCode');
const { addCashTransaction } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  const { from, to, category_id } = req.query;
  let sql = `SELECT e.*, ec.name as category_name FROM expenses e LEFT JOIN expense_categories ec ON ec.id = e.category_id WHERE 1=1`;
  const params = [];
  if (from) { sql += ' AND e.date >= ?'; params.push(from); }
  if (to) { sql += ' AND e.date <= ?'; params.push(to); }
  if (category_id) { sql += ' AND e.category_id = ?'; params.push(category_id); }
  sql += ' ORDER BY e.id DESC';
  res.json(db.prepare(sql).all(...params));
});

router.post('/', requireRole('manager'), (req, res) => {
  const b = req.body;
  if (!(Number(b.amount) > 0)) return res.status(400).json({ error: 'A valid amount is required' });
  const date = b.date || new Date().toISOString().slice(0, 10);
  const method = b.payment_method || 'cash';

  const txn = db.transaction(() => {
    const expenseNo = nextCode(db, 'expenses', 'expense_no', 'EXP');
    db.prepare(`INSERT INTO expenses (expense_no, date, category_id, description, amount, payment_method, notes)
      VALUES (?,?,?,?,?,?,?)`).run(expenseNo, date, b.category_id || null, b.description || '', b.amount, method, b.notes || '');
    if (method === 'cash') {
      addCashTransaction(db, { date, type: 'expense', description: b.description || 'Expense', reference: expenseNo, cashOut: Number(b.amount) });
    }
    return { expense_no: expenseNo };
  });

  try { res.json(txn()); } catch (e) { res.status(400).json({ error: e.message }); }
});

router.post('/:id/void', requireRole('manager'), (req, res) => {
  const exp = db.prepare('SELECT * FROM expenses WHERE id = ?').get(req.params.id);
  if (!exp) return res.status(404).json({ error: 'Expense not found' });
  if (exp.status === 'void') return res.status(400).json({ error: 'Already voided' });
  const date = new Date().toISOString().slice(0, 10);
  const txn = db.transaction(() => {
    if (exp.payment_method === 'cash') {
      addCashTransaction(db, { date, type: 'expense', description: `Void Expense ${exp.expense_no}`, reference: exp.expense_no, cashIn: exp.amount });
    }
    db.prepare("UPDATE expenses SET status='void' WHERE id = ?").run(req.params.id);
  });
  try { txn(); res.json({ success: true }); } catch (e) { res.status(400).json({ error: e.message }); }
});

module.exports = router;
