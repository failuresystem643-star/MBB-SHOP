const express = require('express');
const { db } = require('../db/init');
const { authRequired } = require('../middleware/auth');
const { getCashBalance } = require('../utils/ledger');

const router = express.Router();
router.use(authRequired);

router.get('/', (req, res) => {
  const today = new Date().toISOString().slice(0, 10);

  const todaySales = db.prepare("SELECT COALESCE(SUM(total),0) t, COUNT(*) c FROM sales WHERE date = ? AND status='active'").get(today);
  const todayPurchases = db.prepare("SELECT COALESCE(SUM(total),0) t, COUNT(*) c FROM purchases WHERE date = ? AND status='active'").get(today);
  const todayCashIn = db.prepare("SELECT COALESCE(SUM(cash_in),0) t FROM cash_transactions WHERE date = ?").get(today).t;
  const todayCashOut = db.prepare("SELECT COALESCE(SUM(cash_out),0) t FROM cash_transactions WHERE date = ?").get(today).t;

  const totalReceivable = db.prepare(`
    SELECT COALESCE(SUM(bal),0) t FROM (
      SELECT (
        (SELECT opening_balance FROM customers WHERE id = c.id) +
        (SELECT COALESCE(SUM(debit)-SUM(credit),0) FROM customer_ledger WHERE customer_id = c.id)
      ) as bal
      FROM customers c
    )
  `).get().t;

  const totalPayable = db.prepare(`
    SELECT COALESCE(SUM(bal),0) t FROM (
      SELECT (
        (SELECT opening_balance FROM suppliers WHERE id = s.id) +
        (SELECT COALESCE(SUM(credit)-SUM(debit),0) FROM supplier_ledger WHERE supplier_id = s.id)
      ) as bal
      FROM suppliers s
    )
  `).get().t;

  const stockValue = db.prepare("SELECT COALESCE(SUM(current_stock * purchase_price),0) t FROM items WHERE status='active'").get().t;
  const lowStock = db.prepare("SELECT COUNT(*) c FROM items WHERE status='active' AND current_stock <= min_stock_level AND current_stock > 0").get().c;
  const outOfStock = db.prepare("SELECT COUNT(*) c FROM items WHERE status='active' AND current_stock <= 0").get().c;

  const recentSales = db.prepare(`SELECT s.id, s.invoice_no, s.date, s.total, c.name as customer_name FROM sales s
    JOIN customers c ON c.id = s.customer_id WHERE s.status='active' ORDER BY s.id DESC LIMIT 5`).all();
  const recentPurchases = db.prepare(`SELECT p.id, p.purchase_no, p.date, p.total, s.name as supplier_name FROM purchases p
    JOIN suppliers s ON s.id = p.supplier_id WHERE p.status='active' ORDER BY p.id DESC LIMIT 5`).all();
  const recentPayments = db.prepare(`
    SELECT payment_no, date, amount, 'customer' as type, (SELECT name FROM customers WHERE id = customer_id) as party FROM customer_payments WHERE status='active'
    UNION ALL
    SELECT payment_no, date, amount, 'supplier' as type, (SELECT name FROM suppliers WHERE id = supplier_id) as party FROM supplier_payments WHERE status='active'
    ORDER BY date DESC LIMIT 5
  `).all();

  // Daily sales for last 14 days (chart)
  const dailySales = db.prepare(`
    SELECT date, SUM(total) as total FROM sales WHERE status='active' AND date >= date('now','-13 days') GROUP BY date ORDER BY date
  `).all();
  const dailyPurchases = db.prepare(`
    SELECT date, SUM(total) as total FROM purchases WHERE status='active' AND date >= date('now','-13 days') GROUP BY date ORDER BY date
  `).all();
  const dailyExpenses = db.prepare(`
    SELECT date, SUM(amount) as total FROM expenses WHERE status='active' AND date >= date('now','-13 days') GROUP BY date ORDER BY date
  `).all();
  const monthlySales = db.prepare(`
    SELECT strftime('%Y-%m', date) as month, SUM(total) as total FROM sales WHERE status='active' GROUP BY month ORDER BY month DESC LIMIT 12
  `).all().reverse();

  res.json({
    today_sales: todaySales.t, today_sales_count: todaySales.c,
    today_purchases: todayPurchases.t, today_purchases_count: todayPurchases.c,
    today_cash_in: todayCashIn, today_cash_out: todayCashOut,
    current_cash_balance: getCashBalance(db),
    total_customer_receivable: totalReceivable,
    total_supplier_payable: totalPayable,
    total_stock_value: stockValue,
    low_stock_count: lowStock,
    out_of_stock_count: outOfStock,
    recent_sales: recentSales,
    recent_purchases: recentPurchases,
    recent_payments: recentPayments,
    charts: { daily_sales: dailySales, daily_purchases: dailyPurchases, daily_expenses: dailyExpenses, monthly_sales: monthlySales }
  });
});

module.exports = router;
