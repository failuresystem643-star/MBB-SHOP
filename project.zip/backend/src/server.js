require('dotenv').config();
const express = require('express');
const cors = require('cors');
const os = require('os');
const path = require('path');
const fs = require('fs');

require('./db/init'); // ensures schema is created
require('./db/seed'); // seeds admin user, settings, demo data (idempotent)

const app = express();
app.use(cors()); // allow LAN devices (Android) to call the API
app.use(express.json({ limit: '5mb' }));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/masters', require('./routes/masters'));
app.use('/api/items', require('./routes/items'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/suppliers', require('./routes/suppliers'));
app.use('/api/purchases', require('./routes/purchases'));
app.use('/api/sales', require('./routes/sales'));
app.use('/api/returns', require('./routes/returns'));
app.use('/api/payments', require('./routes/payments'));
app.use('/api/expenses', require('./routes/expenses'));
app.use('/api/cashbook', require('./routes/cashbook'));
app.use('/api/stock', require('./routes/stock'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/backup', require('./routes/backup'));

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// --- Serve the built frontend (frontend/dist) from this same server ---
// This lets everything run as ONE process on ONE device (e.g. inside
// Termux on an Android phone, with no separate PC needed): run this
// backend, then open http://localhost:4000 in the phone's browser.
// Run `npm run build` inside frontend/ first to create frontend/dist.
const FRONTEND_DIST = path.join(__dirname, '..', '..', 'frontend', 'dist');
if (fs.existsSync(FRONTEND_DIST)) {
  app.use(express.static(FRONTEND_DIST));
  // Any non-API GET request falls back to index.html so React Router
  // (BrowserRouter) can handle client-side routes like /sales, /stock, etc.
  app.get(/^(?!\/api).*/, (req, res) => {
    res.sendFile(path.join(FRONTEND_DIST, 'index.html'));
  });
} else {
  console.log('Note: frontend/dist not found yet - run "npm run build" in frontend/ to serve the UI from this server.');
}

// Generic error handler (catches unexpected exceptions from route handlers)
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Unexpected server error: ' + err.message });
});

const PORT = process.env.PORT || 4000;

function getLocalIPs() {
  const nets = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) ips.push(net.address);
    }
  }
  return ips;
}

app.listen(PORT, '0.0.0.0', () => {
  console.log('==============================================');
  console.log(' Shop Management System - Backend Server');
  console.log('==============================================');
  console.log(`Local:    http://localhost:${PORT}`);
  getLocalIPs().forEach(ip => console.log(`Network:  http://${ip}:${PORT}   <-- use this from another device`));
  if (fs.existsSync(FRONTEND_DIST)) {
    console.log('');
    console.log(`Open the app -> http://localhost:${PORT}  (same device, e.g. Termux + Chrome)`);
  }
  console.log('==============================================');
  console.log('Default login -> username: admin / password: admin123');
  console.log('==============================================');
});
