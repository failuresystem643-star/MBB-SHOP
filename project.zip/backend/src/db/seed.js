const bcrypt = require('bcryptjs');
const { db } = require('./init');
const { nextCode } = require('../utils/generateCode');

function seed() {
  const userCount = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  if (userCount === 0) {
    const hash = bcrypt.hashSync('admin123', 10);
    db.prepare(`INSERT INTO users (username, password_hash, full_name, role) VALUES (?,?,?,?)`)
      .run('admin', hash, 'Administrator', 'admin');
    console.log('Created default admin user -> username: admin / password: admin123');
  }

  const defaults = {
    shop_name: 'Al-Noor Construction Materials',
    shop_address: 'Main Bazaar Road, Islamabad',
    shop_phone: '0300-0000000',
    opening_cash: '0',
    allow_negative_stock: 'false',
    invoice_prefix: 'INV',
    purchase_prefix: 'PUR',
    last_backup: ''
  };
  const insertSetting = db.prepare(`INSERT OR IGNORE INTO settings (key, value) VALUES (?,?)`);
  for (const [k, v] of Object.entries(defaults)) insertSetting.run(k, v);

  // Opening cash transaction if cash book empty
  const cashCount = db.prepare('SELECT COUNT(*) c FROM cash_transactions').get().c;
  if (cashCount === 0) {
    db.prepare(`INSERT INTO cash_transactions (txn_no, date, type, description, reference, cash_in, cash_out)
      VALUES (?,?,?,?,?,?,?)`)
      .run(nextCode(db, 'cash_transactions', 'txn_no', 'CT'), new Date().toISOString().slice(0,10),
        'opening', 'Opening Cash Balance', '-', 0, 0);
  }

  const expCatCount = db.prepare('SELECT COUNT(*) c FROM expense_categories').get().c;
  if (expCatCount === 0) {
    const cats = ['Rent', 'Electricity', 'Salaries', 'Transport', 'Maintenance', 'Miscellaneous'];
    const ins = db.prepare('INSERT INTO expense_categories (name) VALUES (?)');
    cats.forEach(c => ins.run(c));
  }

  // Demo data ------------------------------------------------------------
  const demoFlag = db.prepare("SELECT value FROM settings WHERE key='demo_seeded'").get();
  if (!demoFlag) {
    console.log('Seeding demo sample data...');

    const catNames = ['Cement', 'Steel', 'Bricks & Blocks', 'Aggregates', 'Pipes', 'Electrical', 'Plumbing', 'Hardware'];
    const catIns = db.prepare('INSERT INTO categories (name, is_demo) VALUES (?,1)');
    const catIds = {};
    catNames.forEach(n => { catIds[n] = catIns.run(n).lastInsertRowid; });

    const brandNames = ['XYZ', 'Falcon', 'Al-Habib', 'Master', 'Kohinoor'];
    const brandIns = db.prepare('INSERT INTO brands (name, is_demo) VALUES (?,1)');
    const brandIds = {};
    brandNames.forEach(n => { brandIds[n] = brandIns.run(n).lastInsertRowid; });

    const unitNames = ['Bag', 'Ton', 'Piece', 'Foot', 'Cft', 'Number', 'Kg'];
    const unitIns = db.prepare('INSERT INTO units (name, is_demo) VALUES (?,1)');
    const unitIds = {};
    unitNames.forEach(n => { unitIds[n] = unitIns.run(n).lastInsertRowid; });

    const supIns = db.prepare(`INSERT INTO suppliers (supplier_code, name, mobile, address, opening_balance, is_demo) VALUES (?,?,?,?,?,1)`);
    const s1 = supIns.run('SUP-0001', 'Bilal Traders', '0321-1234567', 'Industrial Area, Islamabad', 0).lastInsertRowid;
    const s2 = supIns.run('SUP-0002', 'Punjab Steel Suppliers', '0333-7654321', 'Lahore Road', 0).lastInsertRowid;

    const custIns = db.prepare(`INSERT INTO customers (customer_code, name, mobile, address, opening_balance, is_demo) VALUES (?,?,?,?,?,1)`);
    custIns.run('CUS-0001', 'Walk-in Customer', '-', '-', 0);
    custIns.run('CUS-0002', 'Ahmed Construction Co.', '0300-9998888', 'G-10, Islamabad', 0);

    const items = [
      ['CEMENT-001', 'Cement OPC', 'Cement', 'XYZ', 'Bag', 1450, 1550, 20, 125],
      ['STEEL-001', 'Steel Bar 60 Grade', 'Steel', 'Falcon', 'Ton', 265000, 278000, 2, 10],
      ['BRICK-001', 'Red Clay Bricks', 'Bricks & Blocks', 'Al-Habib', 'Number', 14, 18, 2000, 15000],
      ['SAND-001', 'River Sand', 'Aggregates', 'Master', 'Cft', 90, 110, 100, 800],
      ['CRUSH-001', 'Crush 3/4', 'Aggregates', 'Master', 'Cft', 120, 145, 100, 600],
      ['BLOCK-001', 'Concrete Block 6"', 'Bricks & Blocks', 'Al-Habib', 'Piece', 65, 80, 200, 1200],
      ['PIPE-001', 'PVC Pipe 4"', 'Pipes', 'Kohinoor', 'Foot', 180, 220, 50, 300],
      ['ELEC-001', 'Electrical Wire 7/29', 'Electrical', 'Master', 'Number', 3200, 3600, 10, 40],
      ['PLUMB-001', 'PPR Pipe 1"', 'Plumbing', 'Kohinoor', 'Foot', 95, 120, 50, 250],
      ['HARD-001', 'Door Hinges (Pair)', 'Hardware', 'Falcon', 'Piece', 150, 200, 30, 90]
    ];
    const itemIns = db.prepare(`INSERT INTO items
      (item_code, item_name, category_id, brand_id, unit_id, purchase_price, sale_price, min_stock_level, opening_stock, current_stock, supplier_id, is_demo)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,1)`);
    const stockMovIns = db.prepare(`INSERT INTO stock_movements (item_id, date, type, reference, qty_in, qty_out, balance) VALUES (?,?,?,?,?,?,?)`);
    const today = new Date().toISOString().slice(0,10);

    items.forEach(([code, name, cat, brand, unit, pp, sp, min, opening]) => {
      const id = itemIns.run(code, name, catIds[cat], brandIds[brand], unitIds[unit], pp, sp, min, opening, opening, s1).lastInsertRowid;
      stockMovIns.run(id, today, 'opening', 'Opening Stock', opening, 0, opening);
    });

    db.prepare(`INSERT OR REPLACE INTO settings (key, value) VALUES ('demo_seeded','1')`).run();
    console.log('Demo data seeded: categories, brands, units, 2 suppliers, 2 customers, 10 items.');
  }
}

seed();
module.exports = { seed };
