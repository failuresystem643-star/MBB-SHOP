const { nextCode } = require('./generateCode');

// ---- STOCK ----------------------------------------------------------------
function getCurrentStock(db, itemId) {
  const row = db.prepare('SELECT current_stock FROM items WHERE id = ?').get(itemId);
  return row ? row.current_stock : 0;
}

function moveStock(db, { itemId, date, type, reference, qtyIn = 0, qtyOut = 0 }) {
  const item = db.prepare('SELECT current_stock FROM items WHERE id = ?').get(itemId);
  if (!item) throw new Error('Item not found for stock movement');
  const newBalance = item.current_stock + qtyIn - qtyOut;
  db.prepare('INSERT INTO stock_movements (item_id, date, type, reference, qty_in, qty_out, balance) VALUES (?,?,?,?,?,?,?)')
    .run(itemId, date, type, reference, qtyIn, qtyOut, newBalance);
  db.prepare('UPDATE items SET current_stock = ?, updated_at = datetime(\'now\') WHERE id = ?').run(newBalance, itemId);
  return newBalance;
}

// ---- CUSTOMER LEDGER --------------------------------------------------------
function getCustomerBalance(db, customerId) {
  const last = db.prepare('SELECT balance FROM customer_ledger WHERE customer_id = ? ORDER BY id DESC LIMIT 1').get(customerId);
  if (last) return last.balance;
  const cust = db.prepare('SELECT opening_balance FROM customers WHERE id = ?').get(customerId);
  return cust ? cust.opening_balance : 0;
}

function addCustomerLedgerEntry(db, { customerId, date, reference, description, debit = 0, credit = 0 }) {
  const currentBalance = getCustomerBalance(db, customerId);
  const newBalance = currentBalance + debit - credit;
  db.prepare(`INSERT INTO customer_ledger (customer_id, date, reference, description, debit, credit, balance)
    VALUES (?,?,?,?,?,?,?)`).run(customerId, date, reference, description, debit, credit, newBalance);
  return newBalance;
}

// ---- SUPPLIER LEDGER ---------------------------------------------------------
function getSupplierBalance(db, supplierId) {
  const last = db.prepare('SELECT balance FROM supplier_ledger WHERE supplier_id = ? ORDER BY id DESC LIMIT 1').get(supplierId);
  if (last) return last.balance;
  const sup = db.prepare('SELECT opening_balance FROM suppliers WHERE id = ?').get(supplierId);
  return sup ? sup.opening_balance : 0;
}

function addSupplierLedgerEntry(db, { supplierId, date, reference, description, debit = 0, credit = 0 }) {
  const currentBalance = getSupplierBalance(db, supplierId);
  const newBalance = currentBalance + credit - debit; // For supplier: credit increases payable
  db.prepare(`INSERT INTO supplier_ledger (supplier_id, date, reference, description, debit, credit, balance)
    VALUES (?,?,?,?,?,?,?)`).run(supplierId, date, reference, description, debit, credit, newBalance);
  return newBalance;
}

// ---- CASH BOOK -----------------------------------------------------------------
function getCashBalance(db) {
  const row = db.prepare('SELECT COALESCE(SUM(cash_in),0) i, COALESCE(SUM(cash_out),0) o FROM cash_transactions').get();
  return row.i - row.o;
}

function addCashTransaction(db, { date, type, description, reference, cashIn = 0, cashOut = 0 }) {
  const txnNo = nextCode(db, 'cash_transactions', 'txn_no', 'CT');
  db.prepare(`INSERT INTO cash_transactions (txn_no, date, type, description, reference, cash_in, cash_out)
    VALUES (?,?,?,?,?,?,?)`).run(txnNo, date, type, description, reference, cashIn, cashOut);
  return txnNo;
}

module.exports = {
  getCurrentStock, moveStock,
  getCustomerBalance, addCustomerLedgerEntry,
  getSupplierBalance, addSupplierLedgerEntry,
  getCashBalance, addCashTransaction
};
