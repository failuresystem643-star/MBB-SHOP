// Generates the next sequential code for a table+column, e.g. INV-0001, PUR-0002
function nextCode(db, table, column, prefix) {
  const row = db.prepare(`SELECT ${column} as code FROM ${table} ORDER BY id DESC LIMIT 1`).get();
  let next = 1;
  if (row && row.code) {
    const match = String(row.code).match(/(\d+)$/);
    if (match) next = parseInt(match[1], 10) + 1;
  }
  return `${prefix}-${String(next).padStart(4, '0')}`;
}

module.exports = { nextCode };
