import React from 'react';

export function Loading({ label = 'Loading...' }) {
  return (
    <div className="loading-box">
      <div className="spinner"></div>
      <span>{label}</span>
    </div>
  );
}

export function EmptyState({ label = 'No records found' }) {
  return <div className="empty-state">{label}</div>;
}
