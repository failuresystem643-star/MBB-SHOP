import React, { useState, useRef, useEffect } from 'react';
import { api } from '../api.js';

// Type an item code (or part of name/code) -> pick from suggestions -> onSelect(item)
export default function ItemLookup({ onSelect, placeholder = 'Enter Item Code...' }) {
  const [value, setValue] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const timer = useRef(null);
  const boxRef = useRef(null);

  useEffect(() => {
    function onClickOutside(e) {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  function handleChange(e) {
    const v = e.target.value;
    setValue(v);
    clearTimeout(timer.current);
    if (!v.trim()) { setSuggestions([]); setOpen(false); return; }
    timer.current = setTimeout(async () => {
      try {
        const res = await api.get(`/items/lookup/${encodeURIComponent(v.trim())}`);
        if (res.exact) {
          pick(res.exact);
        } else {
          setSuggestions(res.suggestions);
          setOpen(res.suggestions.length > 0);
        }
      } catch (e) { /* ignore */ }
    }, 250);
  }

  function pick(item) {
    onSelect(item);
    setValue('');
    setSuggestions([]);
    setOpen(false);
  }

  return (
    <div className="item-lookup-box" ref={boxRef}>
      <input
        value={value}
        onChange={handleChange}
        placeholder={placeholder}
        onFocus={() => suggestions.length && setOpen(true)}
        autoComplete="off"
      />
      {open && (
        <div className="item-suggestions">
          {suggestions.map(s => (
            <div key={s.id} className="item-suggestion" onMouseDown={() => pick(s)}>
              <strong>{s.item_code}</strong> - {s.item_name}
              <small>{s.brand_name || '-'} | {s.unit_name || '-'} | Stock: {s.current_stock}</small>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
