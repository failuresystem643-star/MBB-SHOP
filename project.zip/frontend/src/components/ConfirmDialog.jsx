import React from 'react';
import Modal from './Modal.jsx';

export default function ConfirmDialog({ title = 'Please Confirm', message, confirmLabel = 'Confirm', danger = false, onConfirm, onCancel }) {
  return (
    <Modal title={title} onClose={onCancel} width={420}>
      <p style={{ marginBottom: 20, color: 'var(--text-secondary)' }}>{message}</p>
      <div className="form-actions">
        <button className="btn btn-secondary" onClick={onCancel}>Cancel</button>
        <button className={danger ? 'btn btn-danger' : 'btn btn-primary'} onClick={onConfirm}>{confirmLabel}</button>
      </div>
    </Modal>
  );
}
