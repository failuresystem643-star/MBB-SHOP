import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

const NAV = [
  { section: 'Overview', links: [{ to: '/', label: 'Dashboard', icon: '📊', end: true }] },
  {
    section: 'Inventory', links: [
      { to: '/items', label: 'Items', icon: '📦' },
      { to: '/masters', label: 'Categories / Brands / Units', icon: '🏷️' },
      { to: '/stock', label: 'Stock', icon: '📈' }
    ]
  },
  {
    section: 'Transactions', links: [
      { to: '/sales', label: 'Sales (POS)', icon: '🧾' },
      { to: '/purchases', label: 'Purchases', icon: '🛒' },
      { to: '/returns', label: 'Returns', icon: '↩️' },
      { to: '/payments', label: 'Payments / Receipts', icon: '💵' },
      { to: '/expenses', label: 'Expenses', icon: '🧮' }
    ]
  },
  {
    section: 'Parties', links: [
      { to: '/customers', label: 'Customers', icon: '👤' },
      { to: '/suppliers', label: 'Suppliers', icon: '🏭' }
    ]
  },
  {
    section: 'Accounts', links: [
      { to: '/cashbook', label: 'Cash Book', icon: '💰' },
      { to: '/reports', label: 'Reports', icon: '📑' }
    ]
  },
  {
    section: 'System', links: [
      { to: '/settings', label: 'Users / Settings', icon: '⚙️' },
      { to: '/backup', label: 'Backup & Restore', icon: '🗄️' }
    ]
  }
];

export default function Sidebar({ open, onClose }) {
  const { user } = useAuth();
  return (
    <>
      {open && <div className="sidebar-scrim" onClick={onClose}></div>}
      <aside className={`sidebar ${open ? 'sidebar-open' : ''}`}>
        <div className="sidebar-brand">
          <div className="brand-mark">AN</div>
          <div>
            <div className="brand-title">Al-Noor Shop</div>
            <div className="brand-subtitle">Management System</div>
          </div>
        </div>
        <nav className="sidebar-nav">
          {NAV.map(section => (
            <div key={section.section} className="nav-section">
              <div className="nav-section-title">{section.section}</div>
              {section.links.map(link => (
                <NavLink key={link.to} to={link.to} end={link.end} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`} onClick={onClose}>
                  <span className="nav-icon">{link.icon}</span>{link.label}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="user-chip">
            <div className="user-avatar">{(user?.full_name || user?.username || '?')[0]?.toUpperCase()}</div>
            <div>
              <div className="user-name">{user?.full_name || user?.username}</div>
              <div className="user-role">{user?.role}</div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
