// Central API client.
//
// - Opened as a website (http://localhost:5173 or http://<lan-ip>:5173), it
//   uses a relative '/api' path - the dev/preview server proxies that to the
//   backend running on the same PC.
// - Packaged as a native Android app (Capacitor), the app has no dev proxy
//   and is served from a file:// / capacitor:// origin, so it needs the full
//   http://<lan-ip>:4000 address of the PC running the backend. That address
//   is entered once on the Login screen ("Server Address") and saved in
//   localStorage as 'serverUrl'.

function getToken() {
  return localStorage.getItem('token');
}

export function getServerUrl() {
  return localStorage.getItem('serverUrl') || '';
}

export function setServerUrl(url) {
  const clean = (url || '').trim().replace(/\/+$/, '');
  if (clean) localStorage.setItem('serverUrl', clean);
  else localStorage.removeItem('serverUrl');
}

// Builds a full request URL for any /api/... path. Used directly by pages
// that need raw fetch() (e.g. file download/upload in Backup.jsx).
export function apiUrl(path) {
  return `${getServerUrl()}/api${path}`;
}

export function authHeader() {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request(method, path, body) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(apiUrl(path), {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch (e) {
    throw new Error('Cannot reach the server. Make sure the backend is running and you are on the same Wi-Fi network.');
  }

  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }

  if (!res.ok) {
    if (res.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      if (!path.includes('/auth/login')) window.location.href = '/login';
    }
    throw new Error((data && data.error) || `Request failed (${res.status})`);
  }
  return data;
}

export const api = {
  get: (path) => request('GET', path),
  post: (path, body) => request('POST', path, body),
  put: (path, body) => request('PUT', path, body),
  delete: (path) => request('DELETE', path)
};
