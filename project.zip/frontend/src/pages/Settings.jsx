import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function Settings() {
  const { user } = useAuth();
  const [tab, setTab] = useState('general');
  const isAdmin = user?.role === 'admin';

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Users / Settings</h1>
          <div className="page-subtitle">Shop details and user accounts</div>
        </div>
      </div>

      <div className="tabs">
        <div className={`tab ${tab === 'general' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setTab('general')}>General</div>
        {isAdmin && <div className={`tab ${tab === 'users' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setTab('users')}>Users</div>}
        <div className={`tab ${tab === 'password' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setTab('password')}>Change Password</div>
      </div>

      {tab === 'general' && <GeneralSettings isAdmin={isAdmin} />}
      {tab === 'users' && isAdmin && <UsersSettings />}
      {tab === 'password' && <ChangePassword />}
    </div>
  );
}

function GeneralSettings({ isAdmin }) {
  const toast = useToast();
  const [settings, setSettings] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => { api.get('/settings').then(setSettings).catch(e => toast.error(e.message)); }, []);

  function update(key, value) { setSettings(s => ({ ...s, [key]: value })); }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await api.put('/settings', settings);
      toast.success('Settings saved');
    } catch (err) {
      toast.error(err.message);
    } finally { setSaving(false); }
  }

  if (!settings) return <Loading />;

  return (
    <form onSubmit={handleSave} className="card" style={{ maxWidth: 640 }}>
      <div className="form-grid cols-2">
        <div className="field">
          <label>Shop Name</label>
          <input value={settings.shop_name || ''} disabled={!isAdmin} onChange={e => update('shop_name', e.target.value)} />
        </div>
        <div className="field">
          <label>Shop Phone</label>
          <input value={settings.shop_phone || ''} disabled={!isAdmin} onChange={e => update('shop_phone', e.target.value)} />
        </div>
        <div className="field" style={{ gridColumn: '1 / -1' }}>
          <label>Shop Address</label>
          <input value={settings.shop_address || ''} disabled={!isAdmin} onChange={e => update('shop_address', e.target.value)} />
        </div>
        <div className="field">
          <label>Invoice Prefix</label>
          <input value={settings.invoice_prefix || ''} disabled={!isAdmin} onChange={e => update('invoice_prefix', e.target.value)} />
        </div>
        <div className="field">
          <label>Purchase Prefix</label>
          <input value={settings.purchase_prefix || ''} disabled={!isAdmin} onChange={e => update('purchase_prefix', e.target.value)} />
        </div>
        <div className="field">
          <label>Allow Negative Stock</label>
          <select value={settings.allow_negative_stock || 'false'} disabled={!isAdmin} onChange={e => update('allow_negative_stock', e.target.value)}>
            <option value="false">No</option>
            <option value="true">Yes</option>
          </select>
        </div>
        <div className="field">
          <label>Opening Cash</label>
          <input type="number" step="0.01" value={settings.opening_cash || '0'} disabled={!isAdmin} onChange={e => update('opening_cash', e.target.value)} />
        </div>
      </div>
      {isAdmin ? (
        <div className="form-actions">
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save Settings'}</button>
        </div>
      ) : (
        <p className="helper-text">Only an administrator can change these settings.</p>
      )}
    </form>
  );
}

function UsersSettings() {
  const toast = useToast();
  const [users, setUsers] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editUser, setEditUser] = useState(null);

  const load = useCallback(() => {
    api.get('/users').then(setUsers).catch(e => toast.error(e.message));
  }, []);

  useEffect(() => { load(); }, [load]);

  async function toggleActive(u) {
    try {
      await api.put(`/users/${u.id}`, { is_active: u.is_active ? 0 : 1 });
      toast.success(`User ${u.is_active ? 'disabled' : 'enabled'}`);
      load();
    } catch (e) { toast.error(e.message); }
  }

  return (
    <div>
      <div className="page-header" style={{ marginTop: 6 }}>
        <div className="page-subtitle" style={{ margin: 0 }}>Manage staff accounts and roles</div>
        <button className="btn btn-accent" onClick={() => { setEditUser(null); setModalOpen(true); }}>+ New User</button>
      </div>

      {!users ? <Loading /> : users.length === 0 ? <EmptyState label="No users found" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr><th>Username</th><th>Full Name</th><th>Role</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td><strong>{u.username}</strong></td>
                  <td>{u.full_name || '-'}</td>
                  <td style={{ textTransform: 'capitalize' }}>{u.role}</td>
                  <td><span className={`badge ${u.is_active ? 'badge-success' : 'badge-muted'}`}>{u.is_active ? 'active' : 'disabled'}</span></td>
                  <td style={{ display: 'flex', gap: 6 }}>
                    <button className="btn btn-secondary btn-sm" onClick={() => { setEditUser(u); setModalOpen(true); }}>Edit</button>
                    <button className="btn btn-secondary btn-sm" onClick={() => toggleActive(u)}>{u.is_active ? 'Disable' : 'Enable'}</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <UserModal
          user={editUser}
          onClose={() => setModalOpen(false)}
          onSaved={() => { setModalOpen(false); load(); }}
        />
      )}
    </div>
  );
}

function UserModal({ user, onClose, onSaved }) {
  const toast = useToast();
  const isEdit = !!user;
  const [username, setUsername] = useState(user?.username || '');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState(user?.full_name || '');
  const [role, setRole] = useState(user?.role || 'sales');
  const [saving, setSaving] = useState(false);

  async function handleSave(e) {
    e.preventDefault();
    if (!isEdit && (!username || !password)) return toast.error('Username and password are required');
    setSaving(true);
    try {
      if (isEdit) {
        await api.put(`/users/${user.id}`, { full_name: fullName, role, password: password || undefined });
      } else {
        await api.post('/users', { username, password, full_name: fullName, role });
      }
      toast.success(`User ${isEdit ? 'updated' : 'created'}`);
      onSaved();
    } catch (err) {
      toast.error(err.message);
    } finally { setSaving(false); }
  }

  return (
    <Modal title={isEdit ? 'Edit User' : 'New User'} onClose={onClose} width={480}>
      <form onSubmit={handleSave}>
        <div className="form-grid cols-2">
          <div className="field">
            <label>Username {isEdit ? '' : '*'}</label>
            <input value={username} disabled={isEdit} onChange={e => setUsername(e.target.value)} required={!isEdit} />
          </div>
          <div className="field">
            <label>{isEdit ? 'New Password (optional)' : 'Password *'}</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} required={!isEdit} />
          </div>
          <div className="field">
            <label>Full Name</label>
            <input value={fullName} onChange={e => setFullName(e.target.value)} />
          </div>
          <div className="field">
            <label>Role</label>
            <select value={role} onChange={e => setRole(e.target.value)}>
              <option value="admin">Admin</option>
              <option value="manager">Manager</option>
              <option value="sales">Sales</option>
            </select>
          </div>
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save User'}</button>
        </div>
      </form>
    </Modal>
  );
}

function ChangePassword() {
  const toast = useToast();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleSave(e) {
    e.preventDefault();
    if (newPassword.length < 4) return toast.error('New password must be at least 4 characters');
    if (newPassword !== confirmPassword) return toast.error('Passwords do not match');
    setSaving(true);
    try {
      await api.post('/auth/change-password', { currentPassword, newPassword });
      toast.success('Password changed successfully');
      setCurrentPassword(''); setNewPassword(''); setConfirmPassword('');
    } catch (err) {
      toast.error(err.message);
    } finally { setSaving(false); }
  }

  return (
    <form onSubmit={handleSave} className="card" style={{ maxWidth: 420 }}>
      <div className="field">
        <label>Current Password</label>
        <input type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} required />
      </div>
      <div className="field">
        <label>New Password</label>
        <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} required />
      </div>
      <div className="field">
        <label>Confirm New Password</label>
        <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required />
      </div>
      <div className="form-actions">
        <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Change Password'}</button>
      </div>
    </form>
  );
}
