import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function Expenses() {
  const [rows, setRows] = useState(null);
  const [categories, setCategories] = useState([]);
  const [categoryId, setCategoryId] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [voidTarget, setVoidTarget] = useState(null);
  const toast = useToast();

  const load = useCallback(() => {
    setRows(null);
    const qs = categoryId ? `?category_id=${categoryId}` : '';
    api.get(`/expenses${qs}`).then(setRows).catch(e => toast.error(e.message));
  }, [categoryId]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { api.get('/masters/expense-categories').then(setCategories).catch(() => {}); }, []);

  async function handleVoidConfirmed() {
    try {
      await api.post(`/expenses/${voidTarget.id}/void`);
      toast.success('Expense voided');
      setVoidTarget(null);
      load();
    } catch (e) { toast.error(e.message); }
  }

  const total = (rows || []).filter(r => r.status !== 'void').reduce((s, r) => s + Number(r.amount), 0);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Expenses</h1>
          <div className="page-subtitle">Track day-to-day shop expenses - cash payments update the cash book automatically</div>
        </div>
        <button className="btn btn-accent" onClick={() => setModalOpen(true)}>+ New Expense</button>
      </div>

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">Total Expenses{categoryId ? ' (filtered)' : ''}</div>
          <div className="stat-value">Rs. {money(total)}</div>
        </div>
      </div>

      <div className="search-row">
        <select value={categoryId} onChange={e => setCategoryId(e.target.value)} style={{ maxWidth: 240 }}>
          <option value="">All Categories</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      {!rows ? <Loading /> : rows.length === 0 ? <EmptyState label="No expenses recorded yet" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr><th>Expense No</th><th>Date</th><th>Category</th><th>Description</th><th className="num">Amount</th><th>Method</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.id}>
                  <td><strong>{r.expense_no}</strong></td>
                  <td>{r.date}</td>
                  <td>{r.category_name || '-'}</td>
                  <td>{r.description || '-'}</td>
                  <td className="num">{money(r.amount)}</td>
                  <td style={{ textTransform: 'capitalize' }}>{r.payment_method}</td>
                  <td><span className={`badge ${r.status === 'void' ? 'badge-muted' : 'badge-success'}`}>{r.status}</span></td>
                  <td>
                    {r.status !== 'void' && (
                      <button className="btn btn-secondary btn-sm" onClick={() => setVoidTarget(r)}>Void</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <NewExpenseModal
          categories={categories}
          onClose={() => setModalOpen(false)}
          onSaved={() => { setModalOpen(false); load(); }}
        />
      )}

      {voidTarget && (
        <ConfirmDialog
          title="Void Expense"
          message={`Void expense ${voidTarget.expense_no} for Rs. ${money(voidTarget.amount)}? Any cash impact will be reversed.`}
          confirmLabel="Void" danger
          onConfirm={handleVoidConfirmed}
          onCancel={() => setVoidTarget(null)}
        />
      )}
    </div>
  );
}

function NewExpenseModal({ categories, onClose, onSaved }) {
  const toast = useToast();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [categoryId, setCategoryId] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('cash');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleSave(e) {
    e.preventDefault();
    if (!(Number(amount) > 0)) return toast.error('Please enter a valid amount');
    setSaving(true);
    try {
      const res = await api.post('/expenses', {
        date, category_id: categoryId || null, description, amount, payment_method: method, notes
      });
      toast.success(`Expense saved: ${res.expense_no}`);
      onSaved();
    } catch (err) {
      toast.error(err.message);
    } finally { setSaving(false); }
  }

  return (
    <Modal title="New Expense" onClose={onClose} width={520}>
      <form onSubmit={handleSave}>
        <div className="form-grid cols-2">
          <div className="field">
            <label>Category</label>
            <select value={categoryId} onChange={e => setCategoryId(e.target.value)}>
              <option value="">-- None --</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div className="field">
            <label>Amount *</label>
            <input type="number" min="0.01" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} required />
          </div>
          <div className="field">
            <label>Payment Method</label>
            <select value={method} onChange={e => setMethod(e.target.value)}>
              <option value="cash">Cash</option>
              <option value="bank">Bank</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
        <div className="field">
          <label>Description</label>
          <input value={description} onChange={e => setDescription(e.target.value)} placeholder="e.g. Monthly electricity bill" />
        </div>
        <div className="field" style={{ marginTop: 4 }}>
          <label>Notes</label>
          <textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} />
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save Expense'}</button>
        </div>
      </form>
    </Modal>
  );
}
