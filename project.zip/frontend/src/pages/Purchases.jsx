import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import ItemLookup from '../components/ItemLookup.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function Purchases() {
  const [purchases, setPurchases] = useState(null);
  const [q, setQ] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const toast = useToast();

  const load = useCallback(() => {
    api.get(`/purchases${q ? `?q=${encodeURIComponent(q)}` : ''}`).then(setPurchases).catch(e => toast.error(e.message));
  }, [q]);

  useEffect(() => { load(); }, [load]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Purchases</h1>
          <div className="page-subtitle">Record purchases from suppliers - stock and supplier ledger update automatically</div>
        </div>
        <button className="btn btn-accent" onClick={() => setModalOpen(true)}>+ New Purchase</button>
      </div>

      <div className="search-row">
        <input className="search-input" placeholder="Search purchase no or supplier..." value={q} onChange={e => setQ(e.target.value)} />
      </div>

      {!purchases ? <Loading /> : purchases.length === 0 ? <EmptyState label="No purchases recorded yet" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr><th>Purchase No</th><th>Date</th><th>Supplier</th><th className="num">Total</th><th className="num">Paid</th><th className="num">Balance</th><th>Status</th></tr>
            </thead>
            <tbody>
              {purchases.map(p => (
                <tr key={p.id}>
                  <td><strong>{p.purchase_no}</strong></td>
                  <td>{p.date}</td>
                  <td>{p.supplier_name}</td>
                  <td className="num">{money(p.total)}</td>
                  <td className="num">{money(p.paid_amount)}</td>
                  <td className="num">{money(p.remaining_amount)}</td>
                  <td><span className={`badge ${p.status === 'active' ? 'badge-success' : 'badge-muted'}`}>{p.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && <NewPurchaseModal onClose={() => setModalOpen(false)} onSaved={() => { setModalOpen(false); load(); }} />}
    </div>
  );
}

function NewPurchaseModal({ onClose, onSaved }) {
  const toast = useToast();
  const [suppliers, setSuppliers] = useState([]);
  const [supplierId, setSupplierId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [lines, setLines] = useState([]);
  const [discount, setDiscount] = useState(0);
  const [tax, setTax] = useState(0);
  const [paid, setPaid] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { api.get('/suppliers').then(setSuppliers).catch(e => toast.error(e.message)); }, []);

  function addItem(item) {
    if (lines.some(l => l.item_id === item.id)) { toast.info('Item already added, update quantity instead'); return; }
    setLines([...lines, {
      item_id: item.id, item_code: item.item_code, item_name: item.item_name,
      unit_name: item.unit_name, quantity: 1, rate: item.purchase_price, discount: 0, tax: 0
    }]);
  }
  function updateLine(idx, field, value) { const copy = [...lines]; copy[idx][field] = value; setLines(copy); }
  function removeLine(idx) { setLines(lines.filter((_, i) => i !== idx)); }

  const subtotal = lines.reduce((s, l) => s + (Number(l.quantity) * Number(l.rate) - Number(l.discount || 0) + Number(l.tax || 0)), 0);
  const total = subtotal - Number(discount || 0) + Number(tax || 0);
  const balance = Math.max(total - Number(paid || 0), 0);

  async function handleSave(e) {
    e.preventDefault();
    if (!supplierId) return toast.error('Please select a supplier');
    if (lines.length === 0) return toast.error('Add at least one item');
    setSaving(true);
    try {
      const res = await api.post('/purchases', {
        supplier_id: supplierId, date, discount, tax, paid_amount: paid, payment_method: paymentMethod, notes,
        items: lines.map(l => ({ item_id: l.item_id, quantity: l.quantity, rate: l.rate, discount: l.discount, tax: l.tax }))
      });
      toast.success(`Purchase saved: ${res.purchase_no}`);
      onSaved();
    } catch (err) {
      toast.error(err.message);
    } finally { setSaving(false); }
  }

  return (
    <Modal title="New Purchase" onClose={onClose} width={820}>
      <form onSubmit={handleSave}>
        <div className="form-grid cols-3">
          <div className="field">
            <label>Supplier *</label>
            <select value={supplierId} onChange={e => setSupplierId(e.target.value)} required>
              <option value="">-- Select Supplier --</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div className="field">
            <label>Payment Method</label>
            <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)}>
              <option value="cash">Cash</option>
              <option value="credit">Credit</option>
              <option value="bank">Bank</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>

        <div className="section-title">Items</div>
        <ItemLookup onSelect={addItem} placeholder="Type Item Code or Name to add..." />

        {lines.length > 0 && (
          <div className="table-wrap" style={{ marginTop: 12 }}>
            <table className="data-table">
              <thead>
                <tr><th>Item</th><th>Unit</th><th className="num">Qty</th><th className="num">Rate</th><th className="num">Discount</th><th className="num">Total</th><th></th></tr>
              </thead>
              <tbody>
                {lines.map((l, idx) => {
                  const lineTotal = Number(l.quantity) * Number(l.rate) - Number(l.discount || 0) + Number(l.tax || 0);
                  return (
                    <tr key={l.item_id}>
                      <td>{l.item_code} - {l.item_name}</td>
                      <td>{l.unit_name || '-'}</td>
                      <td className="num"><input type="number" min="0.01" step="0.01" style={{ width: 70 }} value={l.quantity} onChange={e => updateLine(idx, 'quantity', e.target.value)} /></td>
                      <td className="num"><input type="number" min="0" step="0.01" style={{ width: 90 }} value={l.rate} onChange={e => updateLine(idx, 'rate', e.target.value)} /></td>
                      <td className="num"><input type="number" min="0" step="0.01" style={{ width: 80 }} value={l.discount} onChange={e => updateLine(idx, 'discount', e.target.value)} /></td>
                      <td className="num">{money(lineTotal)}</td>
                      <td><button type="button" className="btn btn-danger btn-sm" onClick={() => removeLine(idx)}>&times;</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
          <div className="invoice-totals">
            <div className="row"><span>Subtotal</span><span>{money(subtotal)}</span></div>
            <div className="row"><span>Discount</span><input type="number" style={{ width: 100, textAlign: 'right' }} value={discount} onChange={e => setDiscount(e.target.value)} /></div>
            <div className="row"><span>Tax</span><input type="number" style={{ width: 100, textAlign: 'right' }} value={tax} onChange={e => setTax(e.target.value)} /></div>
            <div className="row grand"><span>Total</span><span>Rs. {money(total)}</span></div>
            <div className="row"><span>Paid Amount</span><input type="number" style={{ width: 100, textAlign: 'right' }} value={paid} onChange={e => setPaid(e.target.value)} /></div>
            <div className="row"><span>Balance</span><span className={balance > 0 ? 'text-danger' : 'text-success'}>{money(balance)}</span></div>
          </div>
        </div>

        <div className="field" style={{ marginTop: 12 }}>
          <label>Notes</label>
          <textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} />
        </div>

        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save Purchase'}</button>
        </div>
      </form>
    </Modal>
  );
}
