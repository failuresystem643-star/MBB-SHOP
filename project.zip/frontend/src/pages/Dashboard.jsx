import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { api } from '../api.js';
import { Loading } from '../components/Loading.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return 'Rs. ' + Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 0 }); }

export default function Dashboard() {
  const [data, setData] = useState(null);
  const toast = useToast();

  useEffect(() => {
    api.get('/dashboard').then(setData).catch(e => toast.error(e.message));
  }, []);

  if (!data) return <Loading label="Loading dashboard..." />;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <div className="page-subtitle">Live overview of today's business activity</div>
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat-card accent-brick">
          <div className="stat-label">Today's Sales</div>
          <div className="stat-value">{money(data.today_sales)}</div>
          <div className="stat-sub">{data.today_sales_count} invoice(s)</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Today's Purchases</div>
          <div className="stat-value">{money(data.today_purchases)}</div>
          <div className="stat-sub">{data.today_purchases_count} purchase(s)</div>
        </div>
        <div className="stat-card accent-success">
          <div className="stat-label">Today's Cash In</div>
          <div className="stat-value">{money(data.today_cash_in)}</div>
        </div>
        <div className="stat-card accent-danger">
          <div className="stat-label">Today's Cash Out</div>
          <div className="stat-value">{money(data.today_cash_out)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Current Cash Balance</div>
          <div className="stat-value">{money(data.current_cash_balance)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Customer Receivable</div>
          <div className="stat-value">{money(data.total_customer_receivable)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Supplier Payable</div>
          <div className="stat-value">{money(data.total_supplier_payable)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total Stock Value</div>
          <div className="stat-value">{money(data.total_stock_value)}</div>
        </div>
        <div className="stat-card accent-danger">
          <div className="stat-label">Low / Out of Stock</div>
          <div className="stat-value">{data.low_stock_count} / {data.out_of_stock_count}</div>
          <div className="stat-sub"><Link to="/stock">View stock &rarr;</Link></div>
        </div>
      </div>

      <div className="grid-2">
        <div className="card">
          <h3 style={{ marginBottom: 14 }}>Daily Sales (last 14 days)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data.charts.daily_sales}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1f4" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => money(v)} />
              <Line type="monotone" dataKey="total" stroke="#c1521c" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <h3 style={{ marginBottom: 14 }}>Purchases vs Expenses</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={mergeCharts(data.charts.daily_purchases, data.charts.daily_expenses)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef1f4" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => money(v)} />
              <Bar dataKey="purchases" fill="#0f2942" />
              <Bar dataKey="expenses" fill="#b6790a" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid-2" style={{ marginTop: 20 }}>
        <div className="card">
          <h3 style={{ marginBottom: 12 }}>Recent Sales</h3>
          {data.recent_sales.length === 0 ? <div className="empty-state">No sales yet</div> : (
            <table className="data-table">
              <thead><tr><th>Invoice</th><th>Customer</th><th className="num">Total</th></tr></thead>
              <tbody>
                {data.recent_sales.map(s => (
                  <tr key={s.id}><td>{s.invoice_no}</td><td>{s.customer_name}</td><td className="num">{money(s.total)}</td></tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <div className="card">
          <h3 style={{ marginBottom: 12 }}>Recent Purchases</h3>
          {data.recent_purchases.length === 0 ? <div className="empty-state">No purchases yet</div> : (
            <table className="data-table">
              <thead><tr><th>Purchase No</th><th>Supplier</th><th className="num">Total</th></tr></thead>
              <tbody>
                {data.recent_purchases.map(p => (
                  <tr key={p.id}><td>{p.purchase_no}</td><td>{p.supplier_name}</td><td className="num">{money(p.total)}</td></tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

function mergeCharts(purchases, expenses) {
  const map = {};
  purchases.forEach(p => { map[p.date] = { date: p.date, purchases: p.total, expenses: 0 }; });
  expenses.forEach(e => {
    if (!map[e.date]) map[e.date] = { date: e.date, purchases: 0, expenses: 0 };
    map[e.date].expenses = e.total;
  });
  return Object.values(map).sort((a, b) => a.date.localeCompare(b.date));
}
