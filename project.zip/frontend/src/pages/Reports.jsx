import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

const TABS = [
  { key: 'profit-summary', label: 'Profit Summary' },
  { key: 'sales', label: 'Sales' },
  { key: 'sales-by-item', label: 'Sales by Item' },
  { key: 'sales-by-customer', label: 'Sales by Customer' },
  { key: 'purchases', label: 'Purchases' },
  { key: 'purchases-by-supplier', label: 'Purchases by Supplier' },
  { key: 'stock', label: 'Stock Valuation' },
  { key: 'customer-outstanding', label: 'Customer Outstanding' },
  { key: 'supplier-outstanding', label: 'Supplier Outstanding' },
  { key: 'expenses', label: 'Expenses' },
  { key: 'sales-returns', label: 'Sales Returns' },
  { key: 'purchase-returns', label: 'Purchase Returns' }
];

const DATE_FILTERED = new Set(['sales', 'sales-by-item', 'sales-by-customer', 'purchases', 'purchases-by-supplier', 'expenses', 'sales-returns', 'purchase-returns', 'profit-summary']);

export default function Reports() {
  const [tab, setTab] = useState('profit-summary');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [data, setData] = useState(null);
  const toast = useToast();

  const load = useCallback(() => {
    setData(null);
    const params = new URLSearchParams();
    if (DATE_FILTERED.has(tab)) {
      if (from) params.set('from', from);
      if (to) params.set('to', to);
    }
    api.get(`/reports/${tab}${params.toString() ? `?${params}` : ''}`).then(setData).catch(e => toast.error(e.message));
  }, [tab, from, to]);

  useEffect(() => { load(); }, [load]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Reports</h1>
          <div className="page-subtitle">Business reports drawn live from Sales, Purchases, Stock, Ledgers and Expenses</div>
        </div>
      </div>

      <div className="tabs">
        {TABS.map(t => (
          <div key={t.key} className={`tab ${tab === t.key ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setTab(t.key)}>{t.label}</div>
        ))}
      </div>

      {DATE_FILTERED.has(tab) && (
        <div className="search-row">
          <label style={{ fontSize: 13 }}>From <input type="date" value={from} onChange={e => setFrom(e.target.value)} /></label>
          <label style={{ fontSize: 13 }}>To <input type="date" value={to} onChange={e => setTo(e.target.value)} /></label>
          {(from || to) && <button className="btn btn-secondary btn-sm" onClick={() => { setFrom(''); setTo(''); }}>Clear</button>}
        </div>
      )}

      {!data ? <Loading /> : <ReportBody tab={tab} data={data} />}
    </div>
  );
}

function ReportBody({ tab, data }) {
  switch (tab) {
    case 'profit-summary': return <ProfitSummary data={data} />;
    case 'sales': return <SalesReport data={data} />;
    case 'purchases': return <PurchasesReport data={data} />;
    case 'sales-by-item': return <SalesByItem rows={data} />;
    case 'sales-by-customer': return <SalesByCustomer rows={data} />;
    case 'purchases-by-supplier': return <PurchasesBySupplier rows={data} />;
    case 'stock': return <StockValuation rows={data} />;
    case 'customer-outstanding': return <CustomerOutstanding rows={data} />;
    case 'supplier-outstanding': return <SupplierOutstanding rows={data} />;
    case 'expenses': return <ExpensesReport data={data} />;
    case 'sales-returns': return <SalesReturns rows={data} />;
    case 'purchase-returns': return <PurchaseReturns rows={data} />;
    default: return null;
  }
}

function ProfitSummary({ data }) {
  return (
    <div>
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-label">Gross Sales</div>
          <div className="stat-value">{money(data.gross_sales)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Cost of Goods Sold</div>
          <div className="stat-value">{money(data.cost_of_goods_sold)}</div>
        </div>
        <div className="stat-card accent-success">
          <div className="stat-label">Gross Profit</div>
          <div className="stat-value">{money(data.gross_profit)}</div>
        </div>
        <div className="stat-card accent-brick">
          <div className="stat-label">Total Expenses</div>
          <div className="stat-value">{money(data.total_expenses)}</div>
        </div>
        <div className="stat-card accent-success">
          <div className="stat-label">Net Profit</div>
          <div className="stat-value">{money(data.net_profit)}</div>
        </div>
      </div>
      <p className="helper-text">{data.note}</p>
    </div>
  );
}

function SalesReport({ data }) {
  if (data.rows.length === 0) return <EmptyState label="No sales in this range" />;
  return (
    <>
      <div className="stat-grid">
        <div className="stat-card"><div className="stat-label">Total Sales</div><div className="stat-value">{money(data.totals.total)}</div></div>
        <div className="stat-card"><div className="stat-label">Total Paid</div><div className="stat-value">{money(data.totals.paid)}</div></div>
        <div className="stat-card accent-danger"><div className="stat-label">Total Outstanding</div><div className="stat-value">{money(data.totals.remaining)}</div></div>
      </div>
      <div className="table-wrap">
        <table className="data-table">
          <thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th className="num">Total</th><th className="num">Paid</th><th className="num">Balance</th></tr></thead>
          <tbody>
            {data.rows.map(r => (
              <tr key={r.id}><td>{r.invoice_no}</td><td>{r.date}</td><td>{r.customer_name}</td>
                <td className="num">{money(r.total)}</td><td className="num">{money(r.paid_amount)}</td><td className="num">{money(r.remaining_amount)}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function PurchasesReport({ data }) {
  if (data.rows.length === 0) return <EmptyState label="No purchases in this range" />;
  return (
    <>
      <div className="stat-grid">
        <div className="stat-card"><div className="stat-label">Total Purchases</div><div className="stat-value">{money(data.totals.total)}</div></div>
        <div className="stat-card"><div className="stat-label">Total Paid</div><div className="stat-value">{money(data.totals.paid)}</div></div>
        <div className="stat-card accent-danger"><div className="stat-label">Total Outstanding</div><div className="stat-value">{money(data.totals.remaining)}</div></div>
      </div>
      <div className="table-wrap">
        <table className="data-table">
          <thead><tr><th>Purchase No</th><th>Date</th><th>Supplier</th><th className="num">Total</th><th className="num">Paid</th><th className="num">Balance</th></tr></thead>
          <tbody>
            {data.rows.map(r => (
              <tr key={r.id}><td>{r.purchase_no}</td><td>{r.date}</td><td>{r.supplier_name}</td>
                <td className="num">{money(r.total)}</td><td className="num">{money(r.paid_amount)}</td><td className="num">{money(r.remaining_amount)}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function SalesByItem({ rows }) {
  if (rows.length === 0) return <EmptyState label="No sales in this range" />;
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Item Code</th><th>Item Name</th><th className="num">Qty Sold</th><th className="num">Total Sales</th><th className="num">Cost</th><th className="num">Profit</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.item_code}><td>{r.item_code}</td><td>{r.item_name}</td><td className="num">{r.qty_sold}</td>
              <td className="num">{money(r.total_sales)}</td><td className="num">{money(r.total_cost)}</td>
              <td className="num text-success">{money(r.profit)}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function SalesByCustomer({ rows }) {
  if (rows.length === 0) return <EmptyState label="No sales in this range" />;
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Customer</th><th className="num">Invoices</th><th className="num">Total Sales</th><th className="num">Paid</th><th className="num">Due</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}><td>{r.name}</td><td className="num">{r.invoice_count}</td>
              <td className="num">{money(r.total_sales)}</td><td className="num">{money(r.total_paid)}</td><td className="num">{money(r.total_due)}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function PurchasesBySupplier({ rows }) {
  if (rows.length === 0) return <EmptyState label="No purchases in this range" />;
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Supplier</th><th className="num">Invoices</th><th className="num">Total Purchases</th><th className="num">Paid</th><th className="num">Due</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}><td>{r.name}</td><td className="num">{r.invoice_count}</td>
              <td className="num">{money(r.total_purchases)}</td><td className="num">{money(r.total_paid)}</td><td className="num">{money(r.total_due)}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function StockValuation({ rows }) {
  if (rows.length === 0) return <EmptyState label="No items found" />;
  const total = rows.reduce((s, r) => s + r.stock_value, 0);
  return (
    <>
      <div className="stat-grid"><div className="stat-card"><div className="stat-label">Total Stock Value</div><div className="stat-value">{money(total)}</div></div></div>
      <div className="table-wrap">
        <table className="data-table">
          <thead><tr><th>Item Code</th><th>Item Name</th><th>Category</th><th className="num">Stock</th><th className="num">Cost Rate</th><th className="num">Value</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.item_code}><td>{r.item_code}</td><td>{r.item_name}</td><td>{r.category_name || '-'}</td>
                <td className="num">{r.current_stock}</td><td className="num">{money(r.purchase_price)}</td><td className="num">{money(r.stock_value)}</td>
                <td><span className={`badge ${r.stock_status === 'OK' ? 'badge-success' : r.stock_status === 'Low Stock' ? 'badge-warning' : 'badge-danger'}`}>{r.stock_status}</span></td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function CustomerOutstanding({ rows }) {
  if (rows.length === 0) return <EmptyState label="All customer accounts are settled" />;
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Code</th><th>Customer</th><th>Mobile</th><th className="num">Balance</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}><td>{r.customer_code}</td><td>{r.name}</td><td>{r.mobile || '-'}</td>
              <td className="num"><span className={r.balance > 0 ? 'text-danger' : 'text-success'}>{money(r.balance)}</span></td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function SupplierOutstanding({ rows }) {
  if (rows.length === 0) return <EmptyState label="All supplier accounts are settled" />;
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Code</th><th>Supplier</th><th>Mobile</th><th className="num">Balance</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}><td>{r.supplier_code}</td><td>{r.name}</td><td>{r.mobile || '-'}</td>
              <td className="num"><span className={r.balance > 0 ? 'text-danger' : 'text-success'}>{money(r.balance)}</span></td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ExpensesReport({ data }) {
  if (data.rows.length === 0) return <EmptyState label="No expenses in this range" />;
  return (
    <>
      <div className="stat-grid"><div className="stat-card accent-brick"><div className="stat-label">Total Expenses</div><div className="stat-value">{money(data.total)}</div></div></div>
      <div className="table-wrap">
        <table className="data-table">
          <thead><tr><th>Expense No</th><th>Date</th><th>Category</th><th>Description</th><th className="num">Amount</th></tr></thead>
          <tbody>
            {data.rows.map(r => (
              <tr key={r.id}><td>{r.expense_no}</td><td>{r.date}</td><td>{r.category_name || '-'}</td><td>{r.description || '-'}</td><td className="num">{money(r.amount)}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function SalesReturns({ rows }) {
  if (rows.length === 0) return <EmptyState label="No sales returns in this range" />;
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Return No</th><th>Date</th><th>Customer</th><th className="num">Total</th><th className="num">Refund</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}><td>{r.return_no}</td><td>{r.date}</td><td>{r.customer_name}</td><td className="num">{money(r.total)}</td><td className="num">{money(r.refund_amount)}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function PurchaseReturns({ rows }) {
  if (rows.length === 0) return <EmptyState label="No purchase returns in this range" />;
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Return No</th><th>Date</th><th>Supplier</th><th className="num">Total</th><th className="num">Refund</th></tr></thead>
        <tbody>
          {rows.map(r => (
            <tr key={r.id}><td>{r.return_no}</td><td>{r.date}</td><td>{r.supplier_name}</td><td className="num">{money(r.total)}</td><td className="num">{money(r.refund_amount)}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
