import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import ItemLookup from '../components/ItemLookup.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function Returns() {
  const [tab, setTab] = useState('sales');
  const [rows, setRows] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const toast = useToast();

  const endpoint = tab === 'sales' ? '/returns/sales-returns' : '/returns/purchase-returns';

  const load = useCallback(() => {
    setRows(null);
    api.get(endpoint).then(setRows).catch(e => toast.error(e.message));
  }, [endpoint]);

  useEffect(() => { load(); }, [load]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Returns</h1>
          <div className="page-subtitle">Returns are linked to stock and party ledgers automatically</div>
        </div>
        <button className="btn btn-accent" onClick={() => setModalOpen(true)}>+ New {tab === 'sales' ? 'Sales' : 'Purchase'} Return</button>
      </div>

      <div className="tabs">
        <div className={`tab ${tab === 'sales' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setTab('sales')}>Sales Returns</div>
        <div className={`tab ${tab === 'purchase' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setTab('purchase')}>Purchase Returns</div>
      </div>

      {!rows ? <Loading /> : rows.length === 0 ? <EmptyState label="No returns recorded yet" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr><th>Return No</th><th>Date</th><th>{tab === 'sales' ? 'Customer' : 'Supplier'}</th><th className="num">Total</th><th className="num">Refund</th><th>Status</th></tr>
            </thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.id}>
                  <td><strong>{r.return_no}</strong></td>
                  <td>{r.date}</td>
                  <td>{tab === 'sales' ? r.customer_name : r.supplier_name}</td>
                  <td className="num">{money(r.total)}</td>
                  <td className="num">{money(r.refund_amount)}</td>
                  <td><span className={`badge ${r.status === 'active' ? 'badge-success' : 'badge-muted'}`}>{r.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <NewReturnModal type={tab} onClose={() => setModalOpen(false)} onSaved={() => { setModalOpen(false); load(); }} />
      )}
    </div>
  );
}

function NewReturnModal({ type, onClose, onSaved }) {
  const toast = useToast();
  const isSales = type === 'sales';
  const [parties, setParties] = useState([]);
  const [partyId, setPartyId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [lines, setLines] = useState([]);
  const [refund, setRefund] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get(isSales ? '/customers' : '/suppliers').then(setParties).catch(e => toast.error(e.message));
  }, [isSales]);

  function addItem(item) {
    if (lines.some(l => l.item_id === item.id)) return;
    setLines([...lines, {
      item_id: item.id, item_code: item.item_code, item_name: item.item_name,
      quantity: 1, rate: isSales ? item.sale_price : item.purchase_price
    }]);
  }
  function updateLine(idx, field, value) { const copy = [...lines]; copy[idx][field] = value; setLines(copy); }
  function removeLine(idx) { setLines(lines.filter((_, i) => i !== idx)); }

  const total = lines.reduce((s, l) => s + Number(l.quantity) * Number(l.rate), 0);

  async function handleSave(e) {
    e.preventDefault();
    const partyLabel = isSales ? 'customer' : 'supplier';
    if (!partyId) return toast.error(`Please select a ${partyLabel}`);
    if (lines.length === 0) return toast.error('Add at least one item');
    setSaving(true);
    try {
      const payload = {
        date, refund_amount: refund, payment_method: paymentMethod, notes,
        items: lines.map(l => ({ item_id: l.item_id, quantity: l.quantity, rate: l.rate })),
        [isSales ? 'customer_id' : 'supplier_id']: partyId
      };
      const res = await api.post(isSales ? '/returns/sales-returns' : '/returns/purchase-returns', payload);
      toast.success(`Return saved: ${res.return_no}`);
      onSaved();
    } catch (err) {
      toast.error(err.message);
    } finally { setSaving(false); }
  }

  return (
    <Modal title={`New ${isSales ? 'Sales' : 'Purchase'} Return`} onClose={onClose} width={720}>
      <form onSubmit={handleSave}>
        <div className="form-grid cols-3">
          <div className="field">
            <label>{isSales ? 'Customer' : 'Supplier'} *</label>
            <select value={partyId} onChange={e => setPartyId(e.target.value)} required>
              <option value="">-- Select --</option>
              {parties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div className="field">
            <label>Refund Method</label>
            <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)}>
              <option value="cash">Cash</option>
              <option value="credit">Adjust in Ledger</option>
            </select>
          </div>
        </div>

        <div className="section-title">Items being returned</div>
        <ItemLookup onSelect={addItem} placeholder="Type Item Code or Name..." />

        {lines.length > 0 && (
          <div className="table-wrap" style={{ marginTop: 12 }}>
            <table className="data-table">
              <thead><tr><th>Item</th><th className="num">Qty</th><th className="num">Rate</th><th className="num">Total</th><th></th></tr></thead>
              <tbody>
                {lines.map((l, idx) => (
                  <tr key={l.item_id}>
                    <td>{l.item_code} - {l.item_name}</td>
                    <td className="num"><input type="number" min="0.01" step="0.01" style={{ width: 70 }} value={l.quantity} onChange={e => updateLine(idx, 'quantity', e.target.value)} /></td>
                    <td className="num"><input type="number" min="0" step="0.01" style={{ width: 90 }} value={l.rate} onChange={e => updateLine(idx, 'rate', e.target.value)} /></td>
                    <td className="num">{money(Number(l.quantity) * Number(l.rate))}</td>
                    <td><button type="button" className="btn btn-danger btn-sm" onClick={() => removeLine(idx)}>&times;</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
          <div className="invoice-totals">
            <div className="row grand"><span>Total</span><span>Rs. {money(total)}</span></div>
            <div className="row"><span>Refund Amount</span><input type="number" style={{ width: 100, textAlign: 'right' }} value={refund} onChange={e => setRefund(e.target.value)} /></div>
          </div>
        </div>

        <div className="field" style={{ marginTop: 12 }}>
          <label>Notes / Reason</label>
          <textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} />
        </div>

        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save Return'}</button>
        </div>
      </form>
    </Modal>
  );
}
