import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function Suppliers() {
  const [rows, setRows] = useState(null);
  const [q, setQ] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const toast = useToast();
  const navigate = useNavigate();

  const load = useCallback(() => {
    api.get(`/suppliers${q ? `?q=${encodeURIComponent(q)}` : ''}`).then(setRows).catch(e => toast.error(e.message));
  }, [q]);

  useEffect(() => { load(); }, [load]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Suppliers</h1>
          <div className="page-subtitle">Supplier ledger updates automatically from Purchases and Payments</div>
        </div>
        <button className="btn btn-accent" onClick={() => { setEditing(null); setModalOpen(true); }}>+ New Supplier</button>
      </div>

      <div className="search-row">
        <input className="search-input" placeholder="Search by name, mobile, or code..." value={q} onChange={e => setQ(e.target.value)} />
      </div>

      {!rows ? <Loading /> : rows.length === 0 ? <EmptyState label="No suppliers found" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Code</th><th>Name</th><th>Mobile</th><th>Address</th><th className="num">Current Balance</th><th></th></tr></thead>
            <tbody>
              {rows.map(s => (
                <tr key={s.id}>
                  <td>{s.supplier_code}</td>
                  <td><strong>{s.name}</strong></td>
                  <td>{s.mobile || '-'}</td>
                  <td>{s.address || '-'}</td>
                  <td className="num"><span className={s.current_balance > 0 ? 'text-danger' : ''}>{money(s.current_balance)}</span></td>
                  <td>
                    <div className="row-actions">
                      <button className="btn btn-secondary btn-sm" onClick={() => navigate(`/suppliers/${s.id}/ledger`)}>Ledger</button>
                      <button className="btn btn-secondary btn-sm" onClick={() => { setEditing(s); setModalOpen(true); }}>Edit</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && <SupplierModal supplier={editing} onClose={() => setModalOpen(false)} onSaved={() => { setModalOpen(false); load(); }} />}
    </div>
  );
}

function SupplierModal({ supplier, onClose, onSaved }) {
  const toast = useToast();
  const [name, setName] = useState(supplier?.name || '');
  const [mobile, setMobile] = useState(supplier?.mobile || '');
  const [address, setAddress] = useState(supplier?.address || '');
  const [opening, setOpening] = useState(supplier?.opening_balance || 0);
  const [saving, setSaving] = useState(false);

  async function handleSave(e) {
    e.preventDefault();
    if (!name.trim()) return toast.error('Name is required');
    setSaving(true);
    try {
      if (supplier) {
        await api.put(`/suppliers/${supplier.id}`, { name, mobile, address });
        toast.success('Supplier updated');
      } else {
        await api.post('/suppliers', { name, mobile, address, opening_balance: opening });
        toast.success('Supplier created');
      }
      onSaved();
    } catch (err) { toast.error(err.message); } finally { setSaving(false); }
  }

  return (
    <Modal title={supplier ? 'Edit Supplier' : 'New Supplier'} onClose={onClose} width={480}>
      <form onSubmit={handleSave}>
        <div className="form-grid cols-1">
          <div className="field"><label>Name *</label><input value={name} onChange={e => setName(e.target.value)} required autoFocus /></div>
          <div className="field"><label>Mobile</label><input value={mobile} onChange={e => setMobile(e.target.value)} /></div>
          <div className="field"><label>Address</label><textarea rows={2} value={address} onChange={e => setAddress(e.target.value)} /></div>
          {!supplier && (
            <div className="field"><label>Opening Balance</label><input type="number" step="0.01" value={opening} onChange={e => setOpening(e.target.value)} /></div>
          )}
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  );
}
