import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function Customers() {
  const [rows, setRows] = useState(null);
  const [q, setQ] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const toast = useToast();
  const navigate = useNavigate();

  const load = useCallback(() => {
    api.get(`/customers${q ? `?q=${encodeURIComponent(q)}` : ''}`).then(setRows).catch(e => toast.error(e.message));
  }, [q]);

  useEffect(() => { load(); }, [load]);

  function openCreate() { setEditing(null); setModalOpen(true); }
  function openEdit(c) { setEditing(c); setModalOpen(true); }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Customers</h1>
          <div className="page-subtitle">Customer ledger updates automatically from Sales and Payments</div>
        </div>
        <button className="btn btn-accent" onClick={openCreate}>+ New Customer</button>
      </div>

      <div className="search-row">
        <input className="search-input" placeholder="Search by name, mobile, or code..." value={q} onChange={e => setQ(e.target.value)} />
      </div>

      {!rows ? <Loading /> : rows.length === 0 ? <EmptyState label="No customers found" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Code</th><th>Name</th><th>Mobile</th><th>Address</th><th className="num">Current Balance</th><th></th></tr></thead>
            <tbody>
              {rows.map(c => (
                <tr key={c.id}>
                  <td>{c.customer_code}</td>
                  <td><strong>{c.name}</strong></td>
                  <td>{c.mobile || '-'}</td>
                  <td>{c.address || '-'}</td>
                  <td className="num"><span className={c.current_balance > 0 ? 'text-danger' : ''}>{money(c.current_balance)}</span></td>
                  <td>
                    <div className="row-actions">
                      <button className="btn btn-secondary btn-sm" onClick={() => navigate(`/customers/${c.id}/ledger`)}>Ledger</button>
                      <button className="btn btn-secondary btn-sm" onClick={() => openEdit(c)}>Edit</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && <CustomerModal customer={editing} onClose={() => setModalOpen(false)} onSaved={() => { setModalOpen(false); load(); }} />}
    </div>
  );
}

function CustomerModal({ customer, onClose, onSaved }) {
  const toast = useToast();
  const [name, setName] = useState(customer?.name || '');
  const [mobile, setMobile] = useState(customer?.mobile || '');
  const [address, setAddress] = useState(customer?.address || '');
  const [opening, setOpening] = useState(customer?.opening_balance || 0);
  const [saving, setSaving] = useState(false);

  async function handleSave(e) {
    e.preventDefault();
    if (!name.trim()) return toast.error('Name is required');
    setSaving(true);
    try {
      if (customer) {
        await api.put(`/customers/${customer.id}`, { name, mobile, address });
        toast.success('Customer updated');
      } else {
        await api.post('/customers', { name, mobile, address, opening_balance: opening });
        toast.success('Customer created');
      }
      onSaved();
    } catch (err) { toast.error(err.message); } finally { setSaving(false); }
  }

  return (
    <Modal title={customer ? 'Edit Customer' : 'New Customer'} onClose={onClose} width={480}>
      <form onSubmit={handleSave}>
        <div className="form-grid cols-1">
          <div className="field"><label>Name *</label><input value={name} onChange={e => setName(e.target.value)} required autoFocus /></div>
          <div className="field"><label>Mobile</label><input value={mobile} onChange={e => setMobile(e.target.value)} /></div>
          <div className="field"><label>Address</label><textarea rows={2} value={address} onChange={e => setAddress(e.target.value)} /></div>
          {!customer && (
            <div className="field"><label>Opening Balance</label><input type="number" step="0.01" value={opening} onChange={e => setOpening(e.target.value)} /></div>
          )}
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  );
}
