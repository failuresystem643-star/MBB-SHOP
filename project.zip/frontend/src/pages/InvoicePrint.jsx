import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { Loading } from '../components/Loading.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function InvoicePrint() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [sale, setSale] = useState(null);
  const [settings, setSettings] = useState(null);

  useEffect(() => {
    api.get(`/sales/${id}`).then(setSale).catch(e => toast.error(e.message));
    api.get('/settings').then(setSettings).catch(() => {});
  }, [id]);

  if (!sale) return <Loading label="Loading invoice..." />;

  return (
    <div>
      <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 24px', borderBottom: '1px solid var(--slate-200)' }}>
        <button className="btn btn-secondary" onClick={() => navigate('/sales')}>&larr; Back to Sales</button>
        <button className="btn btn-primary" onClick={() => window.print()}>Print Invoice</button>
      </div>

      <div className="print-invoice">
        <div className="print-header">
          <div>
            <h2 style={{ margin: 0 }}>{settings?.shop_name || 'Shop'}</h2>
            <div className="helper-text">{settings?.shop_address}</div>
            <div className="helper-text">{settings?.shop_phone}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <h3 style={{ margin: 0 }}>Sales Invoice</h3>
            <div className="helper-text">Invoice No: <strong>{sale.invoice_no}</strong></div>
            <div className="helper-text">Date: {sale.date}</div>
            {sale.status === 'void' && <div className="badge badge-danger" style={{ marginTop: 6 }}>VOID</div>}
          </div>
        </div>

        <div className="grid-2" style={{ marginBottom: 16 }}>
          <div>
            <div className="section-title" style={{ margin: '0 0 6px' }}>Bill To</div>
            <div>{sale.customer_name}</div>
            {sale.customer_mobile && <div className="helper-text">{sale.customer_mobile}</div>}
            {sale.customer_address && <div className="helper-text">{sale.customer_address}</div>}
          </div>
          <div style={{ textAlign: 'right' }}>
            <div className="section-title" style={{ margin: '0 0 6px' }}>Payment</div>
            <div className="helper-text" style={{ textTransform: 'capitalize' }}>Method: {sale.payment_method}</div>
          </div>
        </div>

        <table className="print-table">
          <thead>
            <tr>
              <th>#</th><th>Item</th><th>Unit</th><th className="num">Qty</th><th className="num">Rate</th><th className="num">Discount</th><th className="num">Total</th>
            </tr>
          </thead>
          <tbody>
            {sale.items.map((it, idx) => (
              <tr key={it.id}>
                <td>{idx + 1}</td>
                <td>{it.item_code} - {it.item_name}</td>
                <td>{it.unit_name || '-'}</td>
                <td className="num">{it.quantity}</td>
                <td className="num">{money(it.rate)}</td>
                <td className="num">{money(it.discount)}</td>
                <td className="num">{money(it.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <div className="invoice-totals">
            <div className="row"><span>Subtotal</span><span>{money(sale.subtotal)}</span></div>
            <div className="row"><span>Discount</span><span>{money(sale.discount)}</span></div>
            <div className="row"><span>Tax</span><span>{money(sale.tax)}</span></div>
            <div className="row grand"><span>Total</span><span>Rs. {money(sale.total)}</span></div>
            <div className="row"><span>Paid</span><span>{money(sale.paid_amount)}</span></div>
            <div className="row"><span>Balance</span><span>{money(sale.remaining_amount)}</span></div>
          </div>
        </div>

        {sale.notes && (
          <div style={{ marginTop: 16 }}>
            <div className="section-title" style={{ margin: '0 0 6px' }}>Notes</div>
            <div className="helper-text">{sale.notes}</div>
          </div>
        )}

        <div style={{ marginTop: 40, textAlign: 'center' }} className="helper-text">
          Thank you for your business!
        </div>
      </div>
    </div>
  );
}
