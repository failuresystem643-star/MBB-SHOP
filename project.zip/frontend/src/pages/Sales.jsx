import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import ItemLookup from '../components/ItemLookup.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function Sales() {
  const [sales, setSales] = useState(null);
  const [q, setQ] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const toast = useToast();
  const navigate = useNavigate();

  const load = useCallback(() => {
    api.get(`/sales${q ? `?q=${encodeURIComponent(q)}` : ''}`).then(setSales).catch(e => toast.error(e.message));
  }, [q]);

  useEffect(() => { load(); }, [load]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Sales</h1>
          <div className="page-subtitle">POS-style sales entry, connected to stock, customer ledger and cash book</div>
        </div>
        <button className="btn btn-accent" onClick={() => setModalOpen(true)}>+ New Sale</button>
      </div>

      <div className="search-row">
        <input className="search-input" placeholder="Search invoice no or customer..." value={q} onChange={e => setQ(e.target.value)} />
      </div>

      {!sales ? <Loading /> : sales.length === 0 ? <EmptyState label="No sales recorded yet" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr><th>Invoice</th><th>Date</th><th>Customer</th><th className="num">Total</th><th className="num">Paid</th><th className="num">Balance</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
              {sales.map(s => (
                <tr key={s.id}>
                  <td><strong>{s.invoice_no}</strong></td>
                  <td>{s.date}</td>
                  <td>{s.customer_name}</td>
                  <td className="num">{money(s.total)}</td>
                  <td className="num">{money(s.paid_amount)}</td>
                  <td className="num">{money(s.remaining_amount)}</td>
                  <td><span className={`badge ${s.status === 'active' ? 'badge-success' : 'badge-muted'}`}>{s.status}</span></td>
                  <td><button className="btn btn-secondary btn-sm" onClick={() => navigate(`/invoice/${s.id}`)}>View / Print</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && <NewSaleModal onClose={() => setModalOpen(false)} onSaved={() => { setModalOpen(false); load(); }} />}
    </div>
  );
}

function NewSaleModal({ onClose, onSaved }) {
  const toast = useToast();
  const [customers, setCustomers] = useState([]);
  const [customerId, setCustomerId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [lines, setLines] = useState([]);
  const [discount, setDiscount] = useState(0);
  const [tax, setTax] = useState(0);
  const [paid, setPaid] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => { api.get('/customers').then(setCustomers).catch(e => toast.error(e.message)); }, []);

  function addItem(item) {
    if (lines.some(l => l.item_id === item.id)) {
      toast.info('Item already added, update quantity instead');
      return;
    }
    setLines([...lines, {
      item_id: item.id, item_code: item.item_code, item_name: item.item_name,
      unit_name: item.unit_name, available_stock: item.current_stock,
      quantity: 1, rate: item.sale_price, discount: 0, tax: 0
    }]);
  }

  function updateLine(idx, field, value) {
    const copy = [...lines];
    copy[idx][field] = value;
    setLines(copy);
  }
  function removeLine(idx) {
    setLines(lines.filter((_, i) => i !== idx));
  }

  const subtotal = lines.reduce((s, l) => s + (Number(l.quantity) * Number(l.rate) - Number(l.discount || 0) + Number(l.tax || 0)), 0);
  const total = subtotal - Number(discount || 0) + Number(tax || 0);
  const balance = Math.max(total - Number(paid || 0), 0);

  async function handleSave(e) {
    e.preventDefault();
    if (!customerId) return toast.error('Please select a customer');
    if (lines.length === 0) return toast.error('Add at least one item');
    setSaving(true);
    try {
      const res = await api.post('/sales', {
        customer_id: customerId, date, discount, tax, paid_amount: paid, payment_method: paymentMethod, notes,
        items: lines.map(l => ({ item_id: l.item_id, quantity: l.quantity, rate: l.rate, discount: l.discount, tax: l.tax }))
      });
      toast.success(`Sale saved: ${res.invoice_no}`);
      onSaved();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal title="New Sale" onClose={onClose} width={820}>
      <form onSubmit={handleSave}>
        <div className="form-grid cols-3">
          <div className="field">
            <label>Customer *</label>
            <select value={customerId} onChange={e => setCustomerId(e.target.value)} required>
              <option value="">-- Select Customer --</option>
              {customers.map(c => <option key={c.id} value={c.id}>{c.name}{c.mobile ? ` (${c.mobile})` : ''}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div className="field">
            <label>Payment Method</label>
            <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)}>
              <option value="cash">Cash</option>
              <option value="credit">Credit</option>
              <option value="bank">Bank</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>

        <div className="section-title">Items</div>
        <ItemLookup onSelect={addItem} placeholder="Type Item Code or Name to add..." />

        {lines.length > 0 && (
          <div className="table-wrap" style={{ marginTop: 12 }}>
            <table className="data-table">
              <thead>
                <tr><th>Item</th><th>Unit</th><th className="num">Qty</th><th className="num">Rate</th><th className="num">Discount</th><th className="num">Total</th><th></th></tr>
              </thead>
              <tbody>
                {lines.map((l, idx) => {
                  const lineTotal = Number(l.quantity) * Number(l.rate) - Number(l.discount || 0) + Number(l.tax || 0);
                  return (
                    <tr key={l.item_id}>
                      <td>{l.item_code} - {l.item_name}<div className="helper-text">Available: {l.available_stock}</div></td>
                      <td>{l.unit_name || '-'}</td>
                      <td className="num"><input type="number" min="0.01" step="0.01" style={{ width: 70 }} value={l.quantity} onChange={e => updateLine(idx, 'quantity', e.target.value)} /></td>
                      <td className="num"><input type="number" min="0" step="0.01" style={{ width: 90 }} value={l.rate} onChange={e => updateLine(idx, 'rate', e.target.value)} /></td>
                      <td className="num"><input type="number" min="0" step="0.01" style={{ width: 80 }} value={l.discount} onChange={e => updateLine(idx, 'discount', e.target.value)} /></td>
                      <td className="num">{money(lineTotal)}</td>
                      <td><button type="button" className="btn btn-danger btn-sm" onClick={() => removeLine(idx)}>&times;</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
          <div className="invoice-totals">
            <div className="row"><span>Subtotal</span><span>{money(subtotal)}</span></div>
            <div className="row"><span>Discount</span><input type="number" style={{ width: 100, textAlign: 'right' }} value={discount} onChange={e => setDiscount(e.target.value)} /></div>
            <div className="row"><span>Tax</span><input type="number" style={{ width: 100, textAlign: 'right' }} value={tax} onChange={e => setTax(e.target.value)} /></div>
            <div className="row grand"><span>Total</span><span>Rs. {money(total)}</span></div>
            <div className="row"><span>Paid Amount</span><input type="number" style={{ width: 100, textAlign: 'right' }} value={paid} onChange={e => setPaid(e.target.value)} /></div>
            <div className="row"><span>Balance</span><span className={balance > 0 ? 'text-danger' : 'text-success'}>{money(balance)}</span></div>
          </div>
        </div>

        <div className="field" style={{ marginTop: 12 }}>
          <label>Notes</label>
          <textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} />
        </div>

        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save Sale'}</button>
        </div>
      </form>
    </Modal>
  );
}
