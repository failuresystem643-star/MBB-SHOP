import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function CustomerLedger() {
  const { id } = useParams();
  const [customer, setCustomer] = useState(null);
  const [ledger, setLedger] = useState(null);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const toast = useToast();

  useEffect(() => { api.get(`/customers/${id}`).then(setCustomer).catch(e => toast.error(e.message)); }, [id]);

  function loadLedger() {
    const qs = new URLSearchParams();
    if (from) qs.set('from', from);
    if (to) qs.set('to', to);
    api.get(`/customers/${id}/ledger?${qs}`).then(setLedger).catch(e => toast.error(e.message));
  }
  useEffect(loadLedger, [id]);

  if (!customer) return <Loading />;

  return (
    <div>
      <div className="page-header no-print">
        <div>
          <h1 className="page-title">{customer.name} - Ledger</h1>
          <div className="page-subtitle">{customer.customer_code} | {customer.mobile}</div>
        </div>
        <div className="row-actions">
          <Link to="/customers" className="btn btn-secondary">&larr; Back</Link>
          <button className="btn btn-primary" onClick={() => window.print()}>Print Statement</button>
        </div>
      </div>

      <div className="stat-grid no-print">
        <div className="stat-card"><div className="stat-label">Total Sales</div><div className="stat-value">{money(customer.total_sales)}</div></div>
        <div className="stat-card"><div className="stat-label">Total Paid</div><div className="stat-value">{money(customer.total_paid)}</div></div>
        <div className="stat-card accent-danger"><div className="stat-label">Current Balance</div><div className="stat-value">{money(customer.current_balance)}</div></div>
      </div>

      <div className="search-row no-print">
        <input type="date" value={from} onChange={e => setFrom(e.target.value)} />
        <input type="date" value={to} onChange={e => setTo(e.target.value)} />
        <button className="btn btn-secondary" onClick={loadLedger}>Apply Filter</button>
      </div>

      {!ledger ? <Loading /> : ledger.length === 0 ? <EmptyState label="No ledger entries" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Date</th><th>Reference</th><th>Description</th><th className="num">Debit</th><th className="num">Credit</th><th className="num">Balance</th></tr></thead>
            <tbody>
              {ledger.map(l => (
                <tr key={l.id}>
                  <td>{l.date}</td><td>{l.reference}</td><td>{l.description}</td>
                  <td className="num">{l.debit ? money(l.debit) : '-'}</td>
                  <td className="num">{l.credit ? money(l.credit) : '-'}</td>
                  <td className="num"><strong>{money(l.balance)}</strong></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
