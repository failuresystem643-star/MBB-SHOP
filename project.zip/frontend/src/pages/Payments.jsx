import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function Payments() {
  const [tab, setTab] = useState('customer'); // customer | supplier
  const [rows, setRows] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const toast = useToast();

  const endpoint = tab === 'customer' ? '/payments/customer-payments' : '/payments/supplier-payments';

  const load = useCallback(() => {
    setRows(null);
    api.get(endpoint).then(setRows).catch(e => toast.error(e.message));
  }, [endpoint]);

  useEffect(() => { load(); }, [load]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Payments / Receipts</h1>
          <div className="page-subtitle">Record money received from customers or paid to suppliers - ledgers and cash book update automatically</div>
        </div>
        <button className="btn btn-accent" onClick={() => setModalOpen(true)}>+ New {tab === 'customer' ? 'Receipt' : 'Payment'}</button>
      </div>

      <div className="tabs">
        <div className={`tab ${tab === 'customer' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setTab('customer')}>Customer Receipts</div>
        <div className={`tab ${tab === 'supplier' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setTab('supplier')}>Supplier Payments</div>
      </div>

      {!rows ? <Loading /> : rows.length === 0 ? <EmptyState label={`No ${tab === 'customer' ? 'customer receipts' : 'supplier payments'} recorded yet`} /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>{tab === 'customer' ? 'Receipt' : 'Payment'} No</th>
                <th>Date</th>
                <th>{tab === 'customer' ? 'Customer' : 'Supplier'}</th>
                <th className="num">Amount</th>
                <th>Method</th>
                <th>Reference</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.id}>
                  <td><strong>{r.payment_no}</strong></td>
                  <td>{r.date}</td>
                  <td>{tab === 'customer' ? r.customer_name : r.supplier_name}</td>
                  <td className="num">{money(r.amount)}</td>
                  <td style={{ textTransform: 'capitalize' }}>{r.payment_method}</td>
                  <td>{r.reference || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <NewPaymentModal
          tab={tab}
          onClose={() => setModalOpen(false)}
          onSaved={() => { setModalOpen(false); load(); }}
        />
      )}
    </div>
  );
}

function NewPaymentModal({ tab, onClose, onSaved }) {
  const toast = useToast();
  const isCustomer = tab === 'customer';
  const [parties, setParties] = useState([]);
  const [partyId, setPartyId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('cash');
  const [reference, setReference] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get(isCustomer ? '/customers' : '/suppliers').then(setParties).catch(e => toast.error(e.message));
  }, [isCustomer]);

  async function handleSave(e) {
    e.preventDefault();
    if (!partyId) return toast.error(`Please select a ${isCustomer ? 'customer' : 'supplier'}`);
    if (!(Number(amount) > 0)) return toast.error('Please enter a valid amount');
    setSaving(true);
    try {
      const payload = {
        date, amount, payment_method: method, reference, notes,
        ...(isCustomer ? { customer_id: partyId } : { supplier_id: partyId })
      };
      const res = await api.post(isCustomer ? '/payments/customer-payments' : '/payments/supplier-payments', payload);
      toast.success(`${isCustomer ? 'Receipt' : 'Payment'} saved: ${res.payment_no}`);
      onSaved();
    } catch (err) {
      toast.error(err.message);
    } finally { setSaving(false); }
  }

  return (
    <Modal title={isCustomer ? 'New Customer Receipt' : 'New Supplier Payment'} onClose={onClose} width={520}>
      <form onSubmit={handleSave}>
        <div className="form-grid cols-2">
          <div className="field">
            <label>{isCustomer ? 'Customer' : 'Supplier'} *</label>
            <select value={partyId} onChange={e => setPartyId(e.target.value)} required>
              <option value="">-- Select {isCustomer ? 'Customer' : 'Supplier'} --</option>
              {parties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div className="field">
            <label>Amount *</label>
            <input type="number" min="0.01" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} required />
          </div>
          <div className="field">
            <label>Payment Method</label>
            <select value={method} onChange={e => setMethod(e.target.value)}>
              <option value="cash">Cash</option>
              <option value="bank">Bank</option>
              <option value="cheque">Cheque</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="field">
            <label>Reference</label>
            <input value={reference} onChange={e => setReference(e.target.value)} placeholder="Cheque no, slip no, etc." />
          </div>
        </div>
        <div className="field" style={{ marginTop: 4 }}>
          <label>Notes</label>
          <textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} />
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : `Save ${isCustomer ? 'Receipt' : 'Payment'}`}</button>
        </div>
      </form>
    </Modal>
  );
}
