import React, { useEffect, useState } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function CashBook() {
  const [data, setData] = useState(null);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const toast = useToast();

  function load() {
    const qs = new URLSearchParams();
    if (from) qs.set('from', from);
    if (to) qs.set('to', to);
    api.get(`/cashbook?${qs}`).then(setData).catch(e => toast.error(e.message));
  }
  useEffect(load, [from, to]);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Cash Book</h1>
          <div className="page-subtitle">Automatically updated from Sales, Purchases, Payments and Expenses</div>
        </div>
        <div className="row-actions">
          <button className="btn btn-secondary" onClick={() => window.print()}>Print</button>
          <button className="btn btn-accent" onClick={() => setModalOpen(true)}>+ Manual Entry</button>
        </div>
      </div>

      {data && (
        <div className="stat-grid">
          <div className="stat-card"><div className="stat-label">Current Cash Balance</div><div className="stat-value">{money(data.current_balance)}</div></div>
        </div>
      )}

      <div className="search-row no-print">
        <input type="date" value={from} onChange={e => setFrom(e.target.value)} />
        <input type="date" value={to} onChange={e => setTo(e.target.value)} />
      </div>

      {!data ? <Loading /> : data.transactions.length === 0 ? <EmptyState label="No cash transactions" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Txn No</th><th>Date</th><th>Type</th><th>Description</th><th>Reference</th><th className="num">Cash In</th><th className="num">Cash Out</th><th className="num">Balance</th></tr></thead>
            <tbody>
              {data.transactions.map(t => (
                <tr key={t.id}>
                  <td>{t.txn_no}</td>
                  <td>{t.date}</td>
                  <td><span className="badge badge-info" style={{ textTransform: 'capitalize' }}>{t.type.replace('_', ' ')}</span></td>
                  <td>{t.description}</td>
                  <td>{t.reference}</td>
                  <td className="num text-success">{t.cash_in ? money(t.cash_in) : '-'}</td>
                  <td className="num text-danger">{t.cash_out ? money(t.cash_out) : '-'}</td>
                  <td className="num"><strong>{money(t.balance)}</strong></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && <ManualEntryModal onClose={() => setModalOpen(false)} onSaved={() => { setModalOpen(false); load(); }} />}
    </div>
  );
}

function ManualEntryModal({ onClose, onSaved }) {
  const toast = useToast();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [description, setDescription] = useState('');
  const [reference, setReference] = useState('');
  const [direction, setDirection] = useState('in');
  const [amount, setAmount] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleSave(e) {
    e.preventDefault();
    if (!(Number(amount) > 0)) return toast.error('Enter a valid amount');
    setSaving(true);
    try {
      await api.post('/cashbook/manual', {
        date, description, reference,
        cash_in: direction === 'in' ? amount : 0,
        cash_out: direction === 'out' ? amount : 0
      });
      toast.success('Cash entry recorded');
      onSaved();
    } catch (err) { toast.error(err.message); } finally { setSaving(false); }
  }

  return (
    <Modal title="Manual Cash Entry" onClose={onClose} width={460}>
      <form onSubmit={handleSave}>
        <div className="form-grid cols-1">
          <div className="field">
            <label>Type</label>
            <div className="pill-group">
              <div className={`pill ${direction === 'in' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setDirection('in')}>Cash In (Other Income)</div>
              <div className={`pill ${direction === 'out' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setDirection('out')}>Cash Out (Other Payment)</div>
            </div>
          </div>
          <div className="form-grid">
            <div className="field"><label>Date</label><input type="date" value={date} onChange={e => setDate(e.target.value)} /></div>
            <div className="field"><label>Amount *</label><input type="number" min="0.01" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} required /></div>
          </div>
          <div className="field"><label>Description</label><input value={description} onChange={e => setDescription(e.target.value)} /></div>
          <div className="field"><label>Reference</label><input value={reference} onChange={e => setReference(e.target.value)} /></div>
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  );
}
