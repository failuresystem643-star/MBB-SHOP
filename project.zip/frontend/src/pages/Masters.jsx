import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { useToast } from '../components/Toast.jsx';

const TABS = [
  { key: 'categories', label: 'Categories' },
  { key: 'brands', label: 'Brands' },
  { key: 'units', label: 'Units' },
  { key: 'expense-categories', label: 'Expense Categories' }
];

export default function Masters() {
  const [tab, setTab] = useState('categories');
  const [rows, setRows] = useState(null);
  const [name, setName] = useState('');
  const [editing, setEditing] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const toast = useToast();

  const load = useCallback(() => {
    setRows(null);
    api.get(`/masters/${tab}`).then(setRows).catch(e => toast.error(e.message));
  }, [tab]);

  useEffect(() => { load(); }, [load]);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!name.trim()) return;
    try {
      if (editing) {
        await api.put(`/masters/${tab}/${editing.id}`, { name });
        toast.success('Updated');
      } else {
        await api.post(`/masters/${tab}`, { name });
        toast.success('Added');
      }
      setName('');
      setEditing(null);
      load();
    } catch (err) {
      toast.error(err.message);
    }
  }

  async function handleDelete() {
    try {
      await api.delete(`/masters/${tab}/${deleteTarget.id}`);
      toast.success('Deleted');
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.error(err.message);
      setDeleteTarget(null);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Categories / Brands / Units</h1>
          <div className="page-subtitle">Manage the master lists used throughout the Item Master and Expenses</div>
        </div>
      </div>

      <div className="tabs">
        {TABS.map(t => (
          <div key={t.key} className={`tab ${tab === t.key ? 'active' : ''}`} style={{ cursor: 'pointer' }}
            onClick={() => { setTab(t.key); setName(''); setEditing(null); }}>{t.label}</div>
        ))}
      </div>

      <div className="card" style={{ marginBottom: 18, maxWidth: 480 }}>
        <form onSubmit={handleSubmit} style={{ display: 'flex', gap: 10 }}>
          <input style={{ flex: 1, padding: '9px 11px', border: '1px solid var(--slate-300)', borderRadius: 8 }}
            placeholder={`New ${TABS.find(t => t.key === tab).label.slice(0, -1)} name...`}
            value={name} onChange={e => setName(e.target.value)} />
          <button className="btn btn-primary">{editing ? 'Update' : 'Add'}</button>
          {editing && <button type="button" className="btn btn-secondary" onClick={() => { setEditing(null); setName(''); }}>Cancel</button>}
        </form>
      </div>

      {!rows ? <Loading /> : rows.length === 0 ? <EmptyState /> : (
        <div className="table-wrap" style={{ maxWidth: 480 }}>
          <table className="data-table">
            <thead><tr><th>Name</th><th></th></tr></thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.id}>
                  <td>{r.name}{r.is_demo ? <span className="badge badge-info" style={{ marginLeft: 8 }}>Demo</span> : null}</td>
                  <td>
                    <div className="row-actions">
                      <button className="btn btn-secondary btn-sm" onClick={() => { setEditing(r); setName(r.name); }}>Edit</button>
                      <button className="btn btn-danger btn-sm" onClick={() => setDeleteTarget(r)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete"
          message={`Delete "${deleteTarget.name}"? Items using this will keep their existing reference.`}
          confirmLabel="Delete" danger
          onConfirm={handleDelete} onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  );
}
