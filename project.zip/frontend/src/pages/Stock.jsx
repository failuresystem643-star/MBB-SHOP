import React, { useEffect, useState } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';

function money(n) { return Number(n || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 }); }

export default function Stock() {
  const [data, setData] = useState(null);
  const [filter, setFilter] = useState('all');
  const [q, setQ] = useState('');
  const [movementItem, setMovementItem] = useState(null);
  const toast = useToast();

  useEffect(() => { api.get('/stock/summary').then(setData).catch(e => toast.error(e.message)); }, []);

  if (!data) return <Loading />;

  let items = data.items;
  if (filter === 'low') items = items.filter(i => i.current_stock <= i.min_stock_level && i.current_stock > 0);
  if (filter === 'out') items = items.filter(i => i.current_stock <= 0);
  if (q) items = items.filter(i => i.item_code.toLowerCase().includes(q.toLowerCase()) || i.item_name.toLowerCase().includes(q.toLowerCase()));

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Stock Management</h1>
          <div className="page-subtitle">Current stock is calculated automatically from all transactions</div>
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat-card"><div className="stat-label">Total Stock Value</div><div className="stat-value">{money(data.total_stock_value)}</div></div>
        <div className="stat-card accent-danger"><div className="stat-label">Low Stock Items</div><div className="stat-value">{data.low_stock_count}</div></div>
        <div className="stat-card accent-danger"><div className="stat-label">Out of Stock Items</div><div className="stat-value">{data.out_of_stock_count}</div></div>
      </div>

      <div className="search-row">
        <input className="search-input" placeholder="Search item..." value={q} onChange={e => setQ(e.target.value)} />
        <div className="pill-group">
          <div className={`pill ${filter === 'all' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setFilter('all')}>All</div>
          <div className={`pill ${filter === 'low' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setFilter('low')}>Low Stock</div>
          <div className={`pill ${filter === 'out' ? 'active' : ''}`} style={{ cursor: 'pointer' }} onClick={() => setFilter('out')}>Out of Stock</div>
        </div>
      </div>

      {items.length === 0 ? <EmptyState /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Code</th><th>Item</th><th>Category</th><th>Unit</th><th className="num">Current Stock</th><th className="num">Min Level</th><th className="num">Stock Value</th><th></th></tr></thead>
            <tbody>
              {items.map(i => (
                <tr key={i.id}>
                  <td>{i.item_code}</td>
                  <td>{i.item_name}</td>
                  <td>{i.category_name || '-'}</td>
                  <td>{i.unit_name || '-'}</td>
                  <td className="num">
                    {i.current_stock}
                    {i.current_stock <= 0 && <span className="badge badge-danger" style={{ marginLeft: 6 }}>Out</span>}
                    {i.current_stock > 0 && i.current_stock <= i.min_stock_level && <span className="badge badge-warning" style={{ marginLeft: 6 }}>Low</span>}
                  </td>
                  <td className="num">{i.min_stock_level}</td>
                  <td className="num">{money(i.current_stock * i.purchase_price)}</td>
                  <td><button className="btn btn-secondary btn-sm" onClick={() => setMovementItem(i)}>History</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {movementItem && <MovementModal item={movementItem} onClose={() => setMovementItem(null)} />}
    </div>
  );
}

function MovementModal({ item, onClose }) {
  const [movements, setMovements] = useState(null);
  const toast = useToast();

  useEffect(() => { api.get(`/stock/movement/${item.id}`).then(d => setMovements(d.movements)).catch(e => toast.error(e.message)); }, [item.id]);

  return (
    <Modal title={`Stock Ledger - ${item.item_code} ${item.item_name}`} onClose={onClose} width={620}>
      {!movements ? <Loading /> : movements.length === 0 ? <EmptyState /> : (
        <table className="data-table">
          <thead><tr><th>Date</th><th>Type</th><th>Reference</th><th className="num">In</th><th className="num">Out</th><th className="num">Balance</th></tr></thead>
          <tbody>
            {movements.map(m => (
              <tr key={m.id}>
                <td>{m.date}</td>
                <td style={{ textTransform: 'capitalize' }}>{m.type.replace('_', ' ')}</td>
                <td>{m.reference}</td>
                <td className="num text-success">{m.qty_in || '-'}</td>
                <td className="num text-danger">{m.qty_out || '-'}</td>
                <td className="num"><strong>{m.balance}</strong></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </Modal>
  );
}
