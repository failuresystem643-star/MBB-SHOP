import React, { useEffect, useState, useCallback, useRef } from 'react';
import { Loading, EmptyState } from '../components/Loading.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { useToast } from '../components/Toast.jsx';
import { apiUrl, authHeader } from '../api.js';

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export default function Backup() {
  const [data, setData] = useState(null);
  const [creating, setCreating] = useState(false);
  const [restoreFile, setRestoreFile] = useState(null);
  const [restoring, setRestoring] = useState(false);
  const fileInputRef = useRef(null);
  const toast = useToast();

  const load = useCallback(() => {
    fetch(apiUrl('/backup/list'), { headers: authHeader() })
      .then(r => r.json())
      .then(setData)
      .catch(() => toast.error('Failed to load backup list'));
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleCreate() {
    setCreating(true);
    try {
      const res = await fetch(apiUrl('/backup/create'), { method: 'POST', headers: authHeader() });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Backup failed');
      toast.success(`Backup created: ${json.file}`);
      load();
    } catch (err) { toast.error(err.message); }
    finally { setCreating(false); }
  }

  function handleDownload(name) {
    const url = apiUrl(`/backup/download/${encodeURIComponent(name)}`);
    fetch(url, { headers: authHeader() })
      .then(r => { if (!r.ok) throw new Error('Download failed'); return r.blob(); })
      .then(blob => {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = name;
        link.click();
      })
      .catch(e => toast.error(e.message));
  }

  async function handleRestoreConfirmed() {
    if (!restoreFile) return;
    setRestoring(true);
    try {
      const formData = new FormData();
      formData.append('backup', restoreFile);
      const res = await fetch(apiUrl('/backup/restore'), { method: 'POST', headers: authHeader(), body: formData });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Restore failed');
      toast.success('Restore complete. The server is restarting - please reload this page in a few seconds.');
      setRestoreFile(null);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setRestoring(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Backup &amp; Restore</h1>
          <div className="page-subtitle">Protect your shop data - create backups regularly and store copies safely off-device</div>
        </div>
        <button className="btn btn-accent" onClick={handleCreate} disabled={creating}>{creating ? 'Creating...' : '+ Create Backup Now'}</button>
      </div>

      {data && data.last_backup && (
        <div className="stat-grid">
          <div className="stat-card">
            <div className="stat-label">Last Backup</div>
            <div className="stat-value" style={{ fontSize: 15 }}>{new Date(data.last_backup).toLocaleString()}</div>
          </div>
        </div>
      )}

      <div className="section-title">Available Backups</div>
      {!data ? <Loading /> : data.files.length === 0 ? <EmptyState label="No backups created yet" /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>File Name</th><th>Created</th><th className="num">Size</th><th></th></tr></thead>
            <tbody>
              {data.files.map(f => (
                <tr key={f.name}>
                  <td>{f.name}</td>
                  <td>{new Date(f.created_at).toLocaleString()}</td>
                  <td className="num">{formatSize(f.size)}</td>
                  <td><button className="btn btn-secondary btn-sm" onClick={() => handleDownload(f.name)}>Download</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="section-title">Restore From Backup</div>
      <div className="card" style={{ maxWidth: 560 }}>
        <p className="helper-text" style={{ marginBottom: 12 }}>
          Restoring will replace all current data with the contents of the uploaded backup file. A safety
          snapshot of the current database is taken automatically before restoring. The server will restart
          after a successful restore.
        </p>
        <input ref={fileInputRef} type="file" accept=".db" onChange={e => setRestoreFile(e.target.files?.[0] || null)} />
        {restoreFile && (
          <div className="form-actions">
            <button className="btn btn-secondary" onClick={() => { setRestoreFile(null); if (fileInputRef.current) fileInputRef.current.value = ''; }}>Clear</button>
            <RestoreButton file={restoreFile} restoring={restoring} onConfirm={handleRestoreConfirmed} />
          </div>
        )}
      </div>
    </div>
  );
}

function RestoreButton({ file, restoring, onConfirm }) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  return (
    <>
      <button className="btn btn-danger" disabled={restoring} onClick={() => setConfirmOpen(true)}>
        {restoring ? 'Restoring...' : `Restore from "${file.name}"`}
      </button>
      {confirmOpen && (
        <ConfirmDialog
          title="Restore Database"
          message="This will replace ALL current data with the uploaded backup. This action cannot be undone (a safety snapshot is kept). Continue?"
          confirmLabel="Restore" danger
          onConfirm={() => { setConfirmOpen(false); onConfirm(); }}
          onCancel={() => setConfirmOpen(false)}
        />
      )}
    </>
  );
}
