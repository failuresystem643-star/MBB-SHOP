import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { getServerUrl, setServerUrl } from '../api.js';

// Only the packaged Android app (no dev proxy) needs a server address -
// a plain web browser talks to the backend via a relative '/api' path.
const isNative = typeof window !== 'undefined' &&
  (window.Capacitor?.isNativePlatform?.() || window.location.protocol === 'capacitor:' || window.location.protocol === 'file:');

export default function Login() {
  const { login, user } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showServer, setShowServer] = useState(isNative && !getServerUrl());
  const [serverUrl, setServerUrlField] = useState(getServerUrl());

  if (user) { navigate('/'); return null; }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (isNative) {
      if (!serverUrl.trim()) { setError('Please enter the server address (e.g. http://192.168.1.10:4000)'); setShowServer(true); return; }
      setServerUrl(serverUrl);
    }
    setLoading(true);
    try {
      await login(username, password);
      navigate('/');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-brand">
          <div className="brand-mark" style={{ background: 'var(--brick)', width: 52, height: 52, borderRadius: 14, color: '#fff', fontSize: 18 }}>AN</div>
          <h2 style={{ marginTop: 14 }}>Al-Noor Shop</h2>
          <div style={{ color: 'var(--text-secondary)', fontSize: 13 }}>Construction Materials Management</div>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="form-grid cols-1">
            <div className="field">
              <label>Username</label>
              <input value={username} onChange={e => setUsername(e.target.value)} autoFocus required />
            </div>
            <div className="field">
              <label>Password</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} required />
            </div>
          </div>

          {isNative && (
            <div style={{ marginTop: 14 }}>
              {!showServer ? (
                <button type="button" className="btn btn-secondary btn-sm" onClick={() => setShowServer(true)}>
                  ⚙ Server Address {getServerUrl() ? `(${getServerUrl()})` : ''}
                </button>
              ) : (
                <div className="field">
                  <label>Server Address</label>
                  <input
                    placeholder="http://192.168.1.10:4000"
                    value={serverUrl}
                    onChange={e => setServerUrlField(e.target.value)}
                  />
                  <div className="helper-text">
                    Enter the address printed by the backend server (Network line) - the phone must be on the same Wi-Fi.
                  </div>
                </div>
              )}
            </div>
          )}

          {error && <div className="field-error" style={{ marginTop: 12 }}>{error}</div>}
          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: 20 }} disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
        <div className="helper-text" style={{ marginTop: 16, textAlign: 'center' }}>
          Default: admin / admin123
        </div>
      </div>
    </div>
  );
}
