import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';
import { Loading, EmptyState } from '../components/Loading.jsx';
import Modal from '../components/Modal.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { useToast } from '../components/Toast.jsx';

const emptyForm = {
  item_code: '', item_name: '', category_id: '', brand_id: '', unit_id: '',
  purchase_price: '', sale_price: '', min_stock_level: '', opening_stock: '',
  supplier_id: '', description: '', status: 'active'
};

export default function Items() {
  const [items, setItems] = useState(null);
  const [masters, setMasters] = useState({ categories: [], brands: [], units: [] });
  const [suppliers, setSuppliers] = useState([]);
  const [q, setQ] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const toast = useToast();

  const load = useCallback(() => {
    api.get(`/items${q ? `?q=${encodeURIComponent(q)}` : ''}`).then(setItems).catch(e => toast.error(e.message));
  }, [q]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    Promise.all([api.get('/masters/categories'), api.get('/masters/brands'), api.get('/masters/units'), api.get('/suppliers')])
      .then(([categories, brands, units, sup]) => { setMasters({ categories, brands, units }); setSuppliers(sup); })
      .catch(e => toast.error(e.message));
  }, []);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }
  function openEdit(item) {
    setEditing(item);
    setForm({
      item_code: item.item_code, item_name: item.item_name, category_id: item.category_id || '',
      brand_id: item.brand_id || '', unit_id: item.unit_id || '', purchase_price: item.purchase_price,
      sale_price: item.sale_price, min_stock_level: item.min_stock_level, opening_stock: item.opening_stock,
      supplier_id: item.supplier_id || '', description: item.description || '', status: item.status
    });
    setModalOpen(true);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      if (editing) {
        await api.put(`/items/${editing.id}`, form);
        toast.success('Item updated');
      } else {
        await api.post('/items', form);
        toast.success('Item created');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(err.message);
    }
  }

  async function handleDelete() {
    try {
      await api.delete(`/items/${deleteTarget.id}`);
      toast.success('Item deleted');
      setDeleteTarget(null);
      load();
    } catch (err) {
      toast.error(err.message);
      setDeleteTarget(null);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Items / Products</h1>
          <div className="page-subtitle">Item master used across Sales, Purchases, Stock and Reports</div>
        </div>
        <button className="btn btn-accent" onClick={openCreate}>+ New Item</button>
      </div>

      <div className="search-row">
        <input className="search-input" placeholder="Search by item code or name..." value={q} onChange={e => setQ(e.target.value)} />
      </div>

      {!items ? <Loading /> : items.length === 0 ? <EmptyState label="No items found. Create your first item." /> : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Item Code</th><th>Item Name</th><th>Category</th><th>Brand</th><th>Unit</th>
                <th className="num">Purchase Price</th><th className="num">Sale Price</th><th className="num">Stock</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {items.map(it => (
                <tr key={it.id}>
                  <td><strong>{it.item_code}</strong></td>
                  <td>{it.item_name}</td>
                  <td>{it.category_name || '-'}</td>
                  <td>{it.brand_name || '-'}</td>
                  <td>{it.unit_name || '-'}</td>
                  <td className="num">{Number(it.purchase_price).toLocaleString()}</td>
                  <td className="num">{Number(it.sale_price).toLocaleString()}</td>
                  <td className="num">
                    {it.current_stock}
                    {it.current_stock <= it.min_stock_level && <span className="badge badge-danger" style={{ marginLeft: 6 }}>Low</span>}
                  </td>
                  <td><span className={`badge ${it.status === 'active' ? 'badge-success' : 'badge-muted'}`}>{it.status}</span></td>
                  <td>
                    <div className="row-actions">
                      <button className="btn btn-secondary btn-sm" onClick={() => openEdit(it)}>Edit</button>
                      <button className="btn btn-danger btn-sm" onClick={() => setDeleteTarget(it)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <Modal title={editing ? 'Edit Item' : 'New Item'} onClose={() => setModalOpen(false)} width={640}>
          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              <div className="field">
                <label>Item Code *</label>
                <input value={form.item_code} onChange={e => setForm({ ...form, item_code: e.target.value.toUpperCase() })} required />
              </div>
              <div className="field">
                <label>Item Name *</label>
                <input value={form.item_name} onChange={e => setForm({ ...form, item_name: e.target.value })} required />
              </div>
              <div className="field">
                <label>Category</label>
                <select value={form.category_id} onChange={e => setForm({ ...form, category_id: e.target.value })}>
                  <option value="">-- Select --</option>
                  {masters.categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Brand</label>
                <select value={form.brand_id} onChange={e => setForm({ ...form, brand_id: e.target.value })}>
                  <option value="">-- Select --</option>
                  {masters.brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Unit</label>
                <select value={form.unit_id} onChange={e => setForm({ ...form, unit_id: e.target.value })}>
                  <option value="">-- Select --</option>
                  {masters.units.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Supplier</label>
                <select value={form.supplier_id} onChange={e => setForm({ ...form, supplier_id: e.target.value })}>
                  <option value="">-- Select --</option>
                  {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Purchase Price *</label>
                <input type="number" step="0.01" value={form.purchase_price} onChange={e => setForm({ ...form, purchase_price: e.target.value })} required />
              </div>
              <div className="field">
                <label>Sale Price *</label>
                <input type="number" step="0.01" value={form.sale_price} onChange={e => setForm({ ...form, sale_price: e.target.value })} required />
              </div>
              <div className="field">
                <label>Minimum Stock Level</label>
                <input type="number" step="0.01" value={form.min_stock_level} onChange={e => setForm({ ...form, min_stock_level: e.target.value })} />
              </div>
              {!editing && (
                <div className="field">
                  <label>Opening Stock</label>
                  <input type="number" step="0.01" value={form.opening_stock} onChange={e => setForm({ ...form, opening_stock: e.target.value })} />
                </div>
              )}
              <div className="field">
                <label>Status</label>
                <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
              <div className="field" style={{ gridColumn: '1 / -1' }}>
                <label>Description</label>
                <textarea rows={2} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
              </div>
            </div>
            <div className="form-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setModalOpen(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary">{editing ? 'Save Changes' : 'Create Item'}</button>
            </div>
          </form>
        </Modal>
      )}

      {deleteTarget && (
        <ConfirmDialog
          title="Delete Item"
          message={`Are you sure you want to delete "${deleteTarget.item_name}"? This cannot be undone.`}
          confirmLabel="Delete"
          danger
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  );
}
