import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import Layout from './components/Layout.jsx';

import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Items from './pages/Items.jsx';
import Masters from './pages/Masters.jsx';
import Stock from './pages/Stock.jsx';
import Sales from './pages/Sales.jsx';
import Purchases from './pages/Purchases.jsx';
import Returns from './pages/Returns.jsx';
import Payments from './pages/Payments.jsx';
import Expenses from './pages/Expenses.jsx';
import Customers from './pages/Customers.jsx';
import CustomerLedger from './pages/CustomerLedger.jsx';
import Suppliers from './pages/Suppliers.jsx';
import SupplierLedger from './pages/SupplierLedger.jsx';
import CashBook from './pages/CashBook.jsx';
import Reports from './pages/Reports.jsx';
import Settings from './pages/Settings.jsx';
import Backup from './pages/Backup.jsx';
import InvoicePrint from './pages/InvoicePrint.jsx';

function RequireAuth({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/invoice/:id" element={<RequireAuth><InvoicePrint /></RequireAuth>} />

      <Route path="/" element={<RequireAuth><Layout /></RequireAuth>}>
        <Route index element={<Dashboard />} />
        <Route path="items" element={<Items />} />
        <Route path="masters" element={<Masters />} />
        <Route path="stock" element={<Stock />} />
        <Route path="sales" element={<Sales />} />
        <Route path="purchases" element={<Purchases />} />
        <Route path="returns" element={<Returns />} />
        <Route path="payments" element={<Payments />} />
        <Route path="expenses" element={<Expenses />} />
        <Route path="customers" element={<Customers />} />
        <Route path="customers/:id/ledger" element={<CustomerLedger />} />
        <Route path="suppliers" element={<Suppliers />} />
        <Route path="suppliers/:id/ledger" element={<SupplierLedger />} />
        <Route path="cashbook" element={<CashBook />} />
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<Settings />} />
        <Route path="backup" element={<Backup />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
