import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Frontend dev server binds to 0.0.0.0 so Android devices on the same
// Wi-Fi can open it via http://<windows-pc-ip>:5173
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:4000',
        changeOrigin: true
      }
    }
  },
  preview: {
    host: '0.0.0.0',
    port: 5173
  }
});
